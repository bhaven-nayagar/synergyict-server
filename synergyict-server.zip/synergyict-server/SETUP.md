# SynergyICT Server Setup Guide
## Google SSO + Self-Hosted Stack

---

## Overview

```
Browser  →  Nginx (SSL)  →  Node.js API  →  PostgreSQL
                ↕
         Google Sign-In
         (ID token verification)
```

**What's secured:**
- TLS 1.3 only, HSTS preload
- Google handles all passwords — none stored on your server
- JWT tokens (8hr expiry) for API sessions
- Domain restriction: only @synergyict.co.za Google accounts
- PostgreSQL bound to localhost, never exposed to internet
- UFW firewall: SSH + 80 + 443 only
- fail2ban: brute-force protection on SSH and Nginx
- Rate limiting at Nginx and Express levels
- bcrypt password hashing (not applicable — SSO only)
- All inputs validated before hitting the database

---

## Part 1 — Google Cloud Console Setup (~10 minutes)

### 1.1 Create a Google Cloud project

1. Go to https://console.cloud.google.com
2. Click the project dropdown (top left) → **New Project**
3. Name: `SynergyICT` → **Create**
4. Wait ~30 seconds, then select the new project

### 1.2 Configure the OAuth consent screen

1. In the left sidebar: **APIs & Services → OAuth consent screen**
2. User type: **Internal** ← important, this restricts to your Google Workspace domain
3. Click **Create**
4. Fill in:
   - App name: `SynergyICT Admin`
   - User support email: your email
   - Developer contact: your email
5. Click **Save and Continue** through the remaining steps (no scopes needed)
6. Click **Back to Dashboard**

> **Why Internal?** Selecting Internal means only users in your Google Workspace
> (`@synergyict.co.za`) can authenticate. External users see an error at Google's
> screen before they ever reach your server.

### 1.3 Create OAuth credentials

1. **APIs & Services → Credentials**
2. **+ Create Credentials → OAuth client ID**
3. Application type: **Web application**
4. Name: `SynergyICT Deals Admin`
5. **Authorised JavaScript origins** — add both:
   ```
   https://synergyict.co.za
   http://localhost:3000
   ```
   *(localhost is for local testing — remove it after go-live if you prefer)*
6. **Authorised redirect URIs** — leave blank (we use popup mode, not redirect)
7. Click **Create**
8. Copy your **Client ID** — looks like:
   ```
   123456789012-abcdefghijklmnopqrstuvwxyz123456.apps.googleusercontent.com
   ```
   You'll need this in Part 2.

> Keep the Client Secret somewhere safe, but you won't need it for this
> implementation (we use the Google Identity Services JS library which only
> needs the Client ID on the frontend, and the Client ID + Google's public
> keys on the backend).

---

## Part 2 — VPS Provisioning

### 2.1 Choose and create your VPS

Any Ubuntu 24.04 LTS VPS works. Minimum specs: 1 vCPU, 1GB RAM, 20GB SSD.

Recommended providers:
| Provider | Location | Cost | Notes |
|---|---|---|---|
| Hetzner (Xneelo) | Cape Town | ~R180/mo | SA-based, POPIA-friendly |
| DigitalOcean | EU/US | ~R130/mo | Simplest UI |
| AWS Lightsail | Cape Town | ~R200/mo | SA region available |
| Contabo | EU | ~R130/mo | Best specs/price |

### 2.2 Initial server access

Once your VPS is running, SSH in:
```bash
ssh root@YOUR_SERVER_IP
```

### 2.3 Point your DNS

In your domain registrar's DNS settings, add or update:
```
Type  Name  Value             TTL
A     @     YOUR_SERVER_IP    300
A     www   YOUR_SERVER_IP    300
```

Wait 5–30 minutes. Verify with:
```bash
dig +short synergyict.co.za
# Should return your server IP
```

---

## Part 3 — Automated Setup

### 3.1 Upload the server package

From your local machine:
```bash
scp synergyict-server.zip root@YOUR_SERVER_IP:~
```

### 3.2 Unzip and run the setup script

On the server:
```bash
unzip synergyict-server.zip
cd synergyict-server
bash scripts/setup.sh
```

The script will ask for:
1. **Domain**: `synergyict.co.za`
2. **SSL email**: your email (for Let's Encrypt expiry notices)
3. **Google Client ID**: from Part 1.3
4. **PostgreSQL password**: choose a strong one (save it)
5. **JWT secret**: a random string of 40+ characters

   Generate one with:
   ```bash
   openssl rand -hex 32
   ```

The script takes ~5 minutes and handles everything automatically.

### 3.3 Verify the setup

```bash
# API health check
curl https://synergyict.co.za/api/health

# Should return:
# {"status":"ok","service":"SynergyICT API","database":"connected",...}

# Check service status
systemctl status synergyict-api

# Watch live logs
journalctl -u synergyict-api -f
```

---

## Part 4 — First Login

1. Go to `https://synergyict.co.za/admin.html`
2. Click **Sign in with Google**
3. Choose your `@synergyict.co.za` account
4. You're in — your user is automatically created in the database

Any `@synergyict.co.za` Google Workspace account can log in.
To **block** a specific user:
```sql
-- SSH into server, then:
sudo -u postgres psql synergyict
UPDATE admin_users SET active = false WHERE email = 'person@synergyict.co.za';
\q
```

To see all admin users:
```sql
sudo -u postgres psql synergyict
SELECT email, name, role, active, last_login FROM admin_users;
\q
```

---

## Maintenance

### SSL renewal
Certbot auto-renews. To check:
```bash
certbot renew --dry-run
```

### Restart the API
```bash
systemctl restart synergyict-api
```

### Update the frontend files
```bash
# Upload new files, then:
cp deals.html admin.html /var/www/synergyict/frontend/
# No restart needed — Nginx serves them directly
```

### Update the API
```bash
cp -r api/* /var/www/synergyict/api/
cd /var/www/synergyict/api
npm install --production
systemctl restart synergyict-api
```

### View logs
```bash
journalctl -u synergyict-api -f          # live API logs
tail -f /var/log/nginx/synergyict_error.log  # Nginx errors
cat /var/www/synergyict/api/logs/error.log   # app error log
```

### Database backup
```bash
sudo -u postgres pg_dump synergyict > backup_$(date +%Y%m%d).sql
```

---

## File structure on the server

```
/var/www/synergyict/
├── frontend/
│   ├── deals.html       ← public deals page
│   └── admin.html       ← admin panel (keep URL private)
└── api/
    ├── server.js
    ├── .env             ← secrets (root-only readable)
    ├── logs/
    ├── lib/
    ├── middleware/
    ├── routes/
    └── scripts/
```

---

## Troubleshooting

**Google Sign-In button doesn't appear**
→ Check the Client ID in admin.html matches your Google Cloud credentials
→ Check the JavaScript origin in Google Cloud includes your exact domain

**"Access restricted to @synergyict.co.za accounts"**
→ The logged-in Google account is not from your domain — expected behaviour

**API health check fails**
→ `systemctl status synergyict-api` and `journalctl -u synergyict-api -n 50`
→ Check `.env` file has correct DB credentials

**SSL certificate errors**
→ `certbot renew` and `systemctl reload nginx`
