// ── SynergyICT Shared Navigation & Footer ──
// Injected into every page via <script src="_shared.js"></script>

const HP_LOGO = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAXsElEQVR42uWdeZRU1Z3HP/e+V1tXV2/sItCAIoisKgKK4JqBaCYqcSM6mRmTnCzGidGJx9GZyWQbnYxOzDgxyZhkRnFJXBOC0aioILIEFEVBRXbZaXqp6treu3f+eO9V1/Jq6bZRk6lz3jlNn+pXr373e3/3+/19f/citNaaj+FLa/AeTNDzg/iYPafJx/QlygRLadBaozUIIRACpPh/EkANKOX8bMjK702kFJ0JhRBgmoJwQFAXkkjpRrfovratEUIg5YeLUvFhTGGlQSmNaYiapq7SmtNv2MnGd1KYYYkUEA4KGusMBjcZjBocYMKIIJPHhJjUGmLk4EDBPSxbI6X4UJB5VBHooU1KkIYga2mWv9HNhu1pvnJhM0Gz8BvaykHmqk0pVr/WDWEJCZVLiHuVxWZbg+0mSFMQbTCYODLEWVPqWDAjyqwTIwTcgbKVg0Yp/8QCmB84gE07Myx+roMnXonz5oZu/urSFoKmwLILUelMBsEDyzoRtiYYcN7jTUqBl/dE7v2JjGbNm92seS3BbQ8d5sTWEAvnxFh0TgPjhgd7AnmUcmW/TmFv+hnuk67YmOSux9v4zeo46U4bwhJDwtq7W5k2NpxDnPe3Qji5b9znt7HnQBYjIKj2dEJ4wRHYSmOnNaQVkUaDi0+Pcd3FLZw6LuwE0tZIQ/Rrjuy3AOYHY/2WFN9ZfJjHX+6CjEZEJaGAIJNQTB4fZt1drS6aCvOWYQiefCXORTfvIlBvYKveP5oUIKWTLnRCISOCK+Y1cMtnBzL+2GBuhvTXtO6X21i2xpDQnlBcf88BZl67g8eXdWIEBYEGA+k+tEorLp/TgBSUBMejLfc/3wm6ZKHt1YJl2RopINBoIEzB4qfaOeXL2/nW/YdIWxopcVPDR4xA7y+FgN//McG1P9rHlm1pZMzAMAS2+5DCfW/AgDd/OoaxwwIo3ZOTvOm7/4jF8ddsI96tkAb0V3Ix3QVMd9lMn1THj/9uKDPGOSlEir4P1gdCoFI9+efmXxxk/jd3smVPlmCTmcs3uQ+RoJKKOZPrnOCpwoTuofGJV+J0HcwSqCH39XaGSAnBFpP1byeZc90O7nrySC7lKP0hB9B2c0hb3GbBLbv4/s8PYkYkZlj4Tw0hQGkWzWtwH7jwPdKN5gMvdIIpOBrUVGuwLE2gTmJJuO7f93LNnfuwlTPdPeZw1APoLRbb9meZe/1OnlreRajFdMmyf+ysjKJ5cIALT6t3VYgoQLIUsHl3hlc2JpERia04ai+P0gSbTO59rI0Ft+yms1s5s0Qd5QB6wXv7/Qzzrt/Bxi0pgk0mWas8Ygwp0EnF/FPrGdDgrKz5OcdD469e7CIbt2tSK/2CRlsTajH5w8tdnH/TLtridp+CKHsbvK37spx340527ssSrDewLF11VcQQLDqrwamu6NIAW7bm4eWdEJQl0/tovrKWJtRssnpDggU376Yzqbxs078BVNrJeYc6bebfvItd+7IEo0ZVKiAFWGnFKFdqCRxJVzydVr+d4q330hhh0edc9IGC2GSy+rUEl/zL+9jKqfTUOo6yFrhrrbFtzcLvvM8776UIxoyaeJSUAlKKi2fXEwk6SBMF93busXhZJ6RVQW780IPYbPLs8i6++KP9GJKaSbysPnUdafb1nx3kxZVxQk1m1Wmb/7ciLLnCXX2FEAUDYxqCeErx5CtxiMg+KY/+DGKwxeTnj7Zx95J2TEPUBpJqec80BI+t7OI/HzpEsLnyglGIPrCTiiknhDn5+DBaF9YAbaXRwB/Wd7Nnd4ZAUPJR18ZtpTEbDK6/ex+vvpfGNERVRiAr5T0h4EC7zZd+uB8Z6l2Cl0JAVnP5mZWl2+JlHbl/f9QvrUFIyGQ0f33HXjIuWCp9bVn+Zg7BvOHeAxzYm8EMyZpXJ4FDWkONBp+ZEysgy94DGVKw74jFM+u6ER/x9C2edcF6gw2vd3P7I20YkorAkeUpi2D5xiT3LW0n0Gj0Snx70u3MyXWMGVpeuv12VZx4m0Uo5HgbhnQuKXtfu5Oi52+NXl5SFs4A29YYMYPvP3CYrfuySFGeHZjlEKQ13PTLgyW8rTYIutLN5X5Ka2Te+iulQGm4Z2k7OqNIJXzIlyGQAYEhRXV0CrAybqW6TyUVp7odCDhpSmvHh+nusLj1vkMsvnGYi0JRPYDeqrt0bYKV6xK9rsvlpNuQABfMqEcUSze3CrP7kEXIFJzqvqc4/7Z12Wzdk0ElFGZMlkWAEKAszejhQQY1Gvh/zQp5D0hnNLsOZjly0IKwwHAr4UbM4OHnOvjmwhYmjQ4V1DzLBtCjGrc9cth9kt6NqiEFdtJmwTmNOemWH0Dvx2MGmKy8c1TZ+6Qymo3b0/zgkTYefrYDs84/B2sNhhAs+dZwThwZ6nPu23/E4jer4tz6y4Psb7MxwgJDCDJJm9sfaeP+G4e5sRDlc6BXH1v7Torlr3Zj1PVe2HvS7bNlpFt+IHWOqBddOC7cKePCPHTzMXzt0gFY8VKibbi59rSJEU4c6SDE935VLoAhzSafn9/ECz8YxaAmA53VKKWRUYPHlnexfX8Ww009ZQPoKYN7n+5Ap3qvDDzp1joqxLzJpdLNi6etNJbtqBtbOZdHmzx6owHLdgbk364ZxMiRQay0KlhchBBgaa50ibrWuuce7qU1uc/Iv/L9FA/J6axm/Iggt1w1EJVUSCkwTUGy3eJ/n+twq0faP4CeMuhKKp5c1dUnZZAv3cI+0s3L14YUmEbhVZxbBGAazgMHTcE506LotMrRISEgm9XUDzC5aHZ9CVXKZwTFn2UaooR3CgEB00HY/JOjmPUO89BaQ0jy4ItdrnUh/HOgUo6p8+Lr3ezbk+2TqWMrjYjIHCKEDztOZTVPr0u4nQTuImBDQ73BuVPryhLclpgsSAeGFNhxm3NnNzCsxSzJtd5i9ca2NJu2pZFBkbMO7Kxm5sQIowYHcr/Ln0X1EUk4LIl3O9UZIyTYvDXN2ndSzJoQKVhMzPypBbBkTQJRVLOrlftZ3YppEyNMP65Uunmu21NrE1x8/Q6ISlBOvqTd4qrLB3Du1LoSr9gL8u5DVkHC8XKXl2vLcd3P3bmP9avjzudp94tKePOXYwr8mFwQBBzssOl2i6zezLTTNkvWxJk1IZLzrwumsOHqvuUbu9FBWTLXa5VuV5zZ4IxyBelm1EkiMYNAvSQYlRgDTL56YbNvwcGQgkRKseKtJISc5xICshnF0OFBzj85WkqV3MXw9W1pXn83RXBIgGC9JNJoYBow/4wYJ44MldibnuJ4fkM3KtFT3NVaQ0Dw3GvdJRV1mdO9wLZ9Gd59P4PopanTI91MFp5RXbqpkCRjOcWETEIxYWzlgsOzr3bz/i6n4KDce5FU/OXMemIR6eRanyr3Qy92YiVsdwaApZznvHyuvzfjBebBFzsh0OPNKA0EJRt3pNnbZuUWp54AumjZsC1NNq4wDdEr9ielQCUVc6fUMXpoFdftUI/rJoWAjOKyOTHfGlwPajtB9wRJKQ1BwZVn+ZTJ3NmUsTS/XtFVgForo2gZEuCCGVFfb0YIJwZ/3JREhnsonKNMINFu8/q2dIGTV7D2vbEtDX3Ifwhc6RbLSbdaXDfL1gRiBpeeWR61+9ttnl6XyBUcHKqkGT82zOwJpahVbkPR8o1JtmxLY4ZFDrU6qVgwo56WWHlv5qEXOlHdqsSbkS5l2uAG0PsOMr+U9PbuTK/rSoUjW182H23aVei6eST49El1jBseLDDa81H75CtddB7MEgg49UIpBaQVl86JufU67SPOXNRa2vnifgS/6C881D7ycg9q/YCyaWemlAd6H7LzoAUGvfJlax3Zh1/qxMpz3YQQYGsWzYv5E9QKqDXrDS47s4H8Z89HbUdCsWRNT5Xbl+AXDLL2RW2JyDAE2w9kC55PahdFtoKDHRYYvVtAKo1svuv2q+VdjuvmraJZReOgAJ+aGSvrFb+9O8NKH9Q60i2YM7uKF52la+Mc3NtT5fYI/sLT6wkF/Am+H2qLuShScKDdcvO3x4jcb92dVnQlFcjaywf5IzvXZ2Q91+2VzSk2bUk5rltePvrEyVEGN1Xwil/qIttVhFpLc6W3ihajVjita/cv63R1XE9gZaS8N2NIQXtC8dvV5b0ZDWBAR0KRzKjcL2V+9SOV0b2qBfWMbIxwoLzr9sCyTsj0KAXtwn7R2f4k2KkBUuAV56TbQH/p5qFx58Esy15zqtxKOV1jdlIxbXyEaWPLU6Wn1sY5tLeKNyPy4uTFQOcpBcvunTnRM7Kx8q5bUvHEqsJ8lE0rjh0R5NypdSWLTs4r3pzkzS09XrGH2vOmR3PSLX/R8dD46Io4ySMWAdOhYiJH8GO+BL8AtVJUnX65OPW2M6E0tzkjO/WEyiP79PoE+3aX5qOLZtdTFyolwTnUvlDoFXuoWHRWedTqIhIsXLsy3GRyiQ/BL4fa3lagAKcSETCo2ZLPjezcWBXp1lngutlKI0L+BQcPtYmU4ok8rzgn3Y4N8onp0bKo3bA1zbrNSQx30ZEuaudNqaN1SCnBL4faSi+nmuODwHBAEA7WtoLkj+zCMiNrSMHeNos/rM8jwRLslOKkcWFOHRcp7xW/2s37eaj1pNunZ9ZTHymPWo8E54KbI/gNvgTfkA7jKJZuler/kaAgHMzXwu7PdSFJg1shETUsHtqVbpVG9vGVceKHrCLpprm8JulGqXSbV166pbOaX7/cVVJwGDA0yCdnVEDttkLUVgINNjREJZGgzP1SirxcMLjJALsGKeeN7LyGXku3YIPBZypJtyMWz/hItwljw8zylW5OrntpYzdbi6QbScUFM6I015dSpbKoraC4UJohTWaug0sUFxNaBwfcAIqKN8pmFC1lRtZD41s7M6x+q4gEdzvS7fhjyku3J1bFXekmapRuLgl+vhPsfOmmC9vq/KRbtop0K875tqZ1SKBglhWswhNGBKvmQG9kP3lqtLIof9FHuuW3+fZWus0tL92OxG2WrEkUSreUZszoEGdOqivN0XmofW+7v3QrlwMnjAiWamEPcVPGhKv2KOek29mVpVtxKalHutVXlG5+BYeZEyNMGFFeuv1ubYLD+4qoUtoh+KGAs1ugt9Kt9HtrMAWTx4QK8nBBNWbK6BB1DQaW5c+nPek2ujXEXJ+R9RLzyreSbH4vVVhK6lbMPyXKoMZKBYcy0m1eZem2uIgE20oj66pItyLUVq04WRBtMpncGirgfzLn0WoYPtBk4qgQOqP8A5gn3XxHNr9hMlNUSpLVpJvmV2Wk26dn+aDWRePuQxYr3ugmEJUI4Th4pDUnj48wZXSoLFX63dpEdemWT5YzikmtQYa1mAU+iixO4mdPrYOsP6yrSTfDs0VXl5aSRowMcs4Ud9HxafNdtTnlK93Oz5Nuwocq/ez37cR3ZsgmNZlORSqusI9YZQl+OdTWIhrOmRotiFWBK+cF48IZ9dz2wOGSDzYkZLsVJ59Ux9Qx/tLNMARPr0uw//0sgQbD6XIyBKRsLp4dIxKqvEOTtMKImK4fW126AZw3LcqkO0YiTNe2BLSCc6dHy6J2x4EsL2yoXbrZyvGGPSsgHzhmvi2pNcw4Icy41hDvbE9jhnpWp2LpVmo/ip69boDIy0ciXIN0W1Uq3YYdG+R8H+mWn7fPmBgBIpX5Wx5qpSF4bKUj3YJNZvVGeQlWUjPhuBCn+BhfMp8b20oTMAWXz41BfhdAvig/vZx0gz2HLZ591SXBuke6TTo+nPvwklVUwzNFbb75rpufdCvu53EqJIVXMWKdVOHc5OdPtyNq3FLhGV9XzG3w5aHSj4t97txGwo3OHhCvSKq7nYbJ1iGBXN3Pa87xHvixlV0kDhdJt7TmMreUlHV3muc39QhRKt1spSEoWXRW+Q4H5d7DaawUJRcUfo7XTPmNnx5g4+YURkRW3VLh2bWRZpOrz2nwbR+RxauNrTSjhwa46IwYKmH3JHwBX5jfmKtI5DfwBE3n3w8s6yooJVmWJtpicvU5jQXv8y7TEBzosHlmXbyo4OBMmZnjS6eMpyRkURNRpUtrx3G87Lt7uOPBw5jR2nKfYQhUwmbhnBijBgdKapBOqipizd5Gwg1b05zypW2IQE8enH5cmFBAlC00/vHdVMHU0QrqIiJXLyxmPELAkS6bt3akMdxFwDQEmXaLf/7iYP5p0cCSXOt1E9zyP4d4fk2cQLRKC56GzqRi0440VpVmTT8ECluz/p7RnNQactlBlQDmd6lecdseHlraTrDRSbYqpcov+wJkWPorl1SFJzYERqjQyDI0vP6T0YwfESxov/CCfrjLZtTV75Fos8CsgYpIgQgJzFrahfPqfpkOi89e2Mx9NwwraV4q26HqxML5Qt+5ehBPrugia2mEBLNOVix1+SFBCjCi5QvfzjkLeVQpoTjjlKgTPJ9FxzQES1bHSRyxCDebBfuSK4AQrWrffSQE2JYm2mjy7asG5g758R2bcku30pqxwwLcdOVArC4nFyrlBKncVSmw5a7871SLdANY/ILjujkNmlS9lOpdo7JhCOwum5sXDXDqnVqX3TUgKy3ftoKbFrYweVIdmbhd9bShD/LypFtsUKCidNu6L8tLG7qREXlUNiYahiATt5k2pY4bL2lx257LzztZjYAGA4JffGOoQ03U0dtRlO8VD2kuL90eWdFFusPGNAX6KAyitjShoOQX3xhGwBQlp4vUHEAvJ1m2ZvrYMHd8ZQhWp33UdlR6PYuVpJvSTp2RgDgq+4oNKbC6bO68dghTRoecc2aqzLqqk9LbtfjVC5v5m0tayLQ57lW/T9+M4phjg5w3rbxXvH5Litfero0E9/YVMAWZNosvXNrClxY05TpqqyqVWkfGVvCTa4dw7pwY6SP9G8Sc6zarnmi4vOv24Audfdo9UEvw0kcsPjE3xn99ZWhZytLnAHqM3pCCR/9xODOmRkm3918QvWrHojKum2kIUhnNoyvjEO69+V01eO0Ws6ZHeeTW4a7CETXn+prXVa/o2hCRPPW9YzltSrRfkOhJt4nHhThtfKlXrGynALrs9W527Ej3atdorcibPS3K0u+OoD4sczKx5ufv7ZdVClrqDZ65bQTnnR4j3Wb57ruofWC8Nt8G/632+V6xrfvlBDZPh6fbLP5iTozf/+sImqKyxN/u9wDmB7EhIln63WO55uIWMu0WWtGn3FTS5uvjXxzutFm6Nt4v+4oN6dCxTLvFFxa2sOTbI4iFZYnqOWoB7FEqzia/n319KHfdMIwAkO12+FmtaPRct9knRTjh2PKu25I1cY7sz2J+gGMBvKNEs902QeDuvz+Gn1w3NJea+orsPmsLKXooxrWfamb5f4zi5PERMm0Wyj1roSavoVeuW9+iZ7oyNNNmceqECCvuGsWXL2jKyc8PIg765fxAr+SUsTS3PXyY2x9uI95hIeudU9y8haAYEcrWxOoM3rl3DEOajAK3y+tc2Lovy4mf30rWLmg6rakUJd0T5FTcJtZk8s3LBvD3l7UQMEq9mT4DqT9WM2+Eg6bg1kUDWffjVq5a0ISwNdkOC9ut8+VPkwLp5tfm60m35b2TbtJdIGwN2Q4LqeDqC5pZ9+NW/uHKAQTcZ+2vI6b69whQl3Z4DH7duyl++PgRHlvRRaLdgpDECDkldyEg3WnzxPdG8KlZ9dglbp1zv1O+tp1X30o6G67LHG7mcbf8I0CjzU7r3dcuamb6cX8CR4D6+RUen9uyJ8MDz3fy65e62LgtDRmnvjR0ZIgt/z2aaFgWTF+vrWPduylmfHU7Mtgzd4XoIdpKaywL535ZDWHJpNEhPnNmjCvPbmTssECBFPzYH0JbEki3DucF0laaVZtSPL0uwdLlXZw9s57b/3ZQiXTy8tN19xzgrvsOIZsMlKXBdkcn7xjkWJPBSaNCnD2ljvmn1jNzQiTv847+Mcgf6UHcjolUOKW8jaTJjGbGdTvYsSdDOOIcYtsYlQxuNGkdYjJhRIjJo0Oc1Bpi+ECzZFH7sA7iFh/mf0bgHQWvdfUV0LI1hztthBSY0jlDoS4ky5bCnEXoz/Qo+KOBZo9HftBDZP+sA1jyZB/D/w7j/wBGb0oNUkIMrAAAAABJRU5ErkJggg=='; // injected below

const NAV_HTML = `
<nav id="main-nav">
  <div class="nav-inner">
    <a href="index.html" class="nav-logo">
      <svg width="34" height="34" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
        <g transform="translate(60,60)">
          <polyline points="-44,-34 -20,0 -44,34" fill="none" stroke="#9FE1CB" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="-16,-34 8,0 -16,34" fill="none" stroke="#1D9E75" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="12,-34 36,0 12,34" fill="none" stroke="#0F6E56" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
          <circle cx="50" cy="0" r="9" fill="#185FA5"/>
        </g>
      </svg>
      <span class="nav-logo-text">Synergy<span>ICT</span></span>
    </a>

    <ul class="nav-links">
      <li><a href="index.html" class="nav-link" data-page="home">Home</a></li>
      <li><a href="about.html" class="nav-link" data-page="about">About Us</a></li>

      <!-- Partners mega menu trigger -->
      <li class="has-mega" id="partners-trigger">
        <button class="nav-link mega-trigger" aria-expanded="false">
          Partners <span class="chevron">▾</span>
        </button>
        <div class="mega-menu" id="mega-menu">
          <div class="mega-inner">
            <div class="mega-label">Our Technology Partners</div>
            <div class="mega-brands">
              <a href="hp.html" class="mega-brand">
                <div class="mega-brand-logo hp-logo-wrap">
                  <img src="${HP_LOGO}" alt="HP" class="hp-mega-img">
                </div>
                <div class="mega-brand-info">
                  <div class="mega-brand-name">HP</div>
                  <div class="mega-brand-desc">Large Format · Office · Production</div>
                </div>
                <span class="mega-arrow">→</span>
              </a>
              <a href="konica-minolta.html" class="mega-brand">
                <div class="mega-brand-logo km-logo-wrap" style="background:#fff5f5;padding:6px">
                  <img src="data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJFYmVuZV8yIiB4bWxuczp4PSJuc19leHRlbmQ7IiB4bWxuczppPSJuc19haTsiIHhtbG5zOmdyYXBoPSJuc19ncmFwaHM7IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDUyIDQ1IiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCA1MiA0NTsiIHhtbDpzcGFjZT0icHJlc2VydmUiPgogPHN0eWxlIHR5cGU9InRleHQvY3NzIj4KICAuc3Qwe2ZpbGw6dXJsKCNTVkdJRF8xXyk7fQoJLnN0MXtmaWxsOnVybCgjU1ZHSURfMl8pO30KCS5zdDJ7ZmlsbDp1cmwoI1NWR0lEXzNfKTt9Cgkuc3Qze2ZpbGw6dXJsKCNTVkdJRF80Xyk7fQoJLnN0NHtmaWxsOnVybCgjU1ZHSURfNV8pO30KCS5zdDV7ZmlsbDp1cmwoI1NWR0lEXzZfKTt9CiA8L3N0eWxlPgogPG1ldGFkYXRhPgogIDxzZncgeG1sbnM9Im5zX3NmdzsiPgogICA8c2xpY2VzPgogICA8L3NsaWNlcz4KICAgPHNsaWNlU291cmNlQm91bmRzIGJvdHRvbUxlZnRPcmlnaW49InRydWUiIGhlaWdodD0iNDUiIHdpZHRoPSI1MiIgeD0iNi4yIiB5PSI0Ny43Ij4KICAgPC9zbGljZVNvdXJjZUJvdW5kcz4KICA8L3Nmdz4KIDwvbWV0YWRhdGE+CiA8ZyBpZD0ibG9nbyI+CiAgPGc+CiAgIDxnPgogICAgPGc+CiAgICAgPGc+CiAgICAgIDxnPgogICAgICAgPHJhZGlhbEdyYWRpZW50IGlkPSJTVkdJRF8xXyIgY3g9Ii0xMjEwLjY5NDciIGN5PSItOTYyLjc1NjMiIHI9IjEyMy40NjYiIGdyYWRpZW50VHJhbnNmb3JtPSJtYXRyaXgoMC4yNSAwIDAgMC4yMyAzMjYuMjYzOCAyMzcuMzAzMSkiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj4KICAgICAgICA8c3RvcCBvZmZzZXQ9IjAiIHN0eWxlPSJzdG9wLWNvbG9yOiM5QkM0RjAiPgogICAgICAgIDwvc3RvcD4KICAgICAgICA8c3RvcCBvZmZzZXQ9IjAuNTkiIHN0eWxlPSJzdG9wLWNvbG9yOiMwMDc1RDIiPgogICAgICAgIDwvc3RvcD4KICAgICAgICA8c3RvcCBvZmZzZXQ9IjEiIHN0eWxlPSJzdG9wLWNvbG9yOiMwMTQ4ODAiPgogICAgICAgIDwvc3RvcD4KICAgICAgIDwvcmFkaWFsR3JhZGllbnQ+CiAgICAgICA8cGF0aCBjbGFzcz0ic3QwIiBkPSJNMC4zLDIyLjNMMC4zLDIyLjNDMS4yLDIyLjMsMTgsMjEuNSwyNiwyMS41YzgsMCwyNC44LDAuOCwyNS44LDAuOGMwLjEsMCwwLjItMC4xLDAuMi0wLjIKCQkJCQkJCWMwLTAuNy0wLjEtMS40LTAuMi0yLjJjMC0wLjItMC4xLTAuMi0wLjMtMC4yYy0wLjgsMC0xNy4zLDEuMi0yNS41LDEuMmMtOC4yLDAtMjQuOC0xLjEtMjUuNS0xLjJjLTAuMiwwLTAuMywwLjEtMC4zLDAuMgoJCQkJCQkJYy0wLjEsMC43LTAuMiwxLjUtMC4yLDIuMkMwLjEsMjIuMiwwLjEsMjIuMiwwLjMsMjIuM3oiPgogICAgICAgPC9wYXRoPgogICAgICAgPHJhZGlhbEdyYWRpZW50IGlkPSJTVkdJRF8yXyIgY3g9Ii0xMjEwLjY5NDciIGN5PSItOTYyLjc1NjMiIHI9IjEyMy40NjYiIGdyYWRpZW50VHJhbnNmb3JtPSJtYXRyaXgoMC4yNSAwIDAgMC4yMyAzMjYuMjYzOCAyMzcuMzAzMSkiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj4KICAgICAgICA8c3RvcCBvZmZzZXQ9IjAiIHN0eWxlPSJzdG9wLWNvbG9yOiM5QkM0RjAiPgogICAgICAgIDwvc3RvcD4KICAgICAgICA8c3RvcCBvZmZzZXQ9IjAuNTkiIHN0eWxlPSJzdG9wLWNvbG9yOiMwMDc1RDIiPgogICAgICAgIDwvc3RvcD4KICAgICAgICA8c3RvcCBvZmZzZXQ9IjEiIHN0eWxlPSJzdG9wLWNvbG9yOiMwMTQ4ODAiPgogICAgICAgIDwvc3RvcD4KICAgICAgIDwvcmFkaWFsR3JhZGllbnQ+CiAgICAgICA8cGF0aCBjbGFzcz0ic3QxIiBkPSJNMS41LDE2aDQ5LjFjMC4yLDAsMC4zLTAuMSwwLjItMC4zQzQ3LjQsNi42LDM3LjYsMCwyNiwwUzQuNiw2LjYsMS4yLDE1LjdDMS4yLDE1LjksMS4zLDE2LDEuNSwxNnoiPgogICAgICAgPC9wYXRoPgogICAgICAgPHJhZGlhbEdyYWRpZW50IGlkPSJTVkdJRF8zXyIgY3g9Ii0xMjEwLjY5NDciIGN5PSItOTYyLjc1NjMiIHI9IjEyMy40NjYiIGdyYWRpZW50VHJhbnNmb3JtPSJtYXRyaXgoMC4yNSAwIDAgMC4yMyAzMjYuMjYzOCAyMzcuMzAzMSkiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj4KICAgICAgICA8c3RvcCBvZmZzZXQ9IjAiIHN0eWxlPSJzdG9wLWNvbG9yOiM5QkM0RjAiPgogICAgICAgIDwvc3RvcD4KICAgICAgICA8c3RvcCBvZmZzZXQ9IjAuNTkiIHN0eWxlPSJzdG9wLWNvbG9yOiMwMDc1RDIiPgogICAgICAgIDwvc3RvcD4KICAgICAgICA8c3RvcCBvZmZzZXQ9IjEiIHN0eWxlPSJzdG9wLWNvbG9yOiMwMTQ4ODAiPgogICAgICAgIDwvc3RvcD4KICAgICAgIDwvcmFkaWFsR3JhZGllbnQ+CiAgICAgICA8cGF0aCBjbGFzcz0ic3QyIiBkPSJNMC42LDE5LjJjMC4yLDAsMjAtMC41LDI1LjQtMC41czI1LjIsMC41LDI1LjQsMC41YzAuMiwwLDAuMy0wLjEsMC4yLTAuMmMtMC4xLTAuNy0wLjMtMS41LTAuNi0yLjMKCQkJCQkJCWMwLTAuMS0wLjEtMC4xLTAuMi0wLjFDNTAuOCwxNi41LDI2LDE4LDI2LDE4UzEuMiwxNi41LDEuMSwxNi41Yy0wLjEsMC0wLjIsMC0wLjIsMC4xYy0wLjIsMC44LTAuNCwxLjUtMC42LDIuMwoJCQkJCQkJQzAuMywxOS4xLDAuNCwxOS4yLDAuNiwxOS4yeiI+CiAgICAgICA8L3BhdGg+CiAgICAgICA8cmFkaWFsR3JhZGllbnQgaWQ9IlNWR0lEXzRfIiBjeD0iLTEyMTAuNjk0NyIgY3k9Ii05NjIuNzU2MyIgcj0iMTIzLjQ2NiIgZ3JhZGllbnRUcmFuc2Zvcm09Im1hdHJpeCgwLjI1IDAgMCAwLjIzIDMyNi4yNjM4IDIzNy4zMDMxKSIgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiPgogICAgICAgIDxzdG9wIG9mZnNldD0iMCIgc3R5bGU9InN0b3AtY29sb3I6IzlCQzRGMCI+CiAgICAgICAgPC9zdG9wPgogICAgICAgIDxzdG9wIG9mZnNldD0iMC41OSIgc3R5bGU9InN0b3AtY29sb3I6IzAwNzVEMiI+CiAgICAgICAgPC9zdG9wPgogICAgICAgIDxzdG9wIG9mZnNldD0iMSIgc3R5bGU9InN0b3AtY29sb3I6IzAxNDg4MCI+CiAgICAgICAgPC9zdG9wPgogICAgICAgPC9yYWRpYWxHcmFkaWVudD4KICAgICAgIDxwYXRoIGNsYXNzPSJzdDMiIGQ9Ik01MC41LDI5SDEuNWMtMC4yLDAtMC4zLDAuMS0wLjIsMC4zQzQuNiwzOC40LDE0LjQsNDUsMjYsNDVzMjEuNC02LjYsMjQuOC0xNS43CgkJCQkJCQlDNTAuOCwyOS4xLDUwLjgsMjksNTAuNSwyOXoiPgogICAgICAgPC9wYXRoPgogICAgICAgPHJhZGlhbEdyYWRpZW50IGlkPSJTVkdJRF81XyIgY3g9Ii0xMjEwLjY5NDciIGN5PSItOTYyLjc1NjMiIHI9IjEyMy40NjYiIGdyYWRpZW50VHJhbnNmb3JtPSJtYXRyaXgoMC4yNSAwIDAgMC4yMyAzMjYuMjYzOCAyMzcuMzAzMSkiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj4KICAgICAgICA8c3RvcCBvZmZzZXQ9IjAiIHN0eWxlPSJzdG9wLWNvbG9yOiM5QkM0RjAiPgogICAgICAgIDwvc3RvcD4KICAgICAgICA8c3RvcCBvZmZzZXQ9IjAuNTkiIHN0eWxlPSJzdG9wLWNvbG9yOiMwMDc1RDIiPgogICAgICAgIDwvc3RvcD4KICAgICAgICA8c3RvcCBvZmZzZXQ9IjEiIHN0eWxlPSJzdG9wLWNvbG9yOiMwMTQ4ODAiPgogICAgICAgIDwvc3RvcD4KICAgICAgIDwvcmFkaWFsR3JhZGllbnQ+CiAgICAgICA8cGF0aCBjbGFzcz0ic3Q0IiBkPSJNNTEuNywyMi44QzUwLjgsMjIuNywzNCwyMy41LDI2LDIzLjVjLTgsMC0yNC44LTAuOC0yNS44LTAuOGMtMC4xLDAtMC4yLDAuMS0wLjIsMC4yaDAKCQkJCQkJCWMwLDAuNywwLjEsMS40LDAuMiwyLjJjMCwwLjIsMC4xLDAuMiwwLjMsMC4yYzAuOCwwLDE3LjMtMS4yLDI1LjUtMS4yYzguMiwwLDI0LjgsMS4xLDI1LjUsMS4yYzAuMiwwLDAuMy0wLjEsMC4zLTAuMgoJCQkJCQkJYzAuMS0wLjgsMC4yLTEuNSwwLjItMi4yQzUxLjksMjIuOCw1MS44LDIyLjgsNTEuNywyMi44eiI+CiAgICAgICA8L3BhdGg+CiAgICAgICA8cmFkaWFsR3JhZGllbnQgaWQ9IlNWR0lEXzZfIiBjeD0iLTEyMTAuNjk0NyIgY3k9Ii05NjIuNzU2MyIgcj0iMTIzLjQ2NiIgZ3JhZGllbnRUcmFuc2Zvcm09Im1hdHJpeCgwLjI1IDAgMCAwLjIzIDMyNi4yNjM4IDIzNy4zMDMxKSIgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiPgogICAgICAgIDxzdG9wIG9mZnNldD0iMCIgc3R5bGU9InN0b3AtY29sb3I6IzlCQzRGMCI+CiAgICAgICAgPC9zdG9wPgogICAgICAgIDxzdG9wIG9mZnNldD0iMC41OSIgc3R5bGU9InN0b3AtY29sb3I6IzAwNzVEMiI+CiAgICAgICAgPC9zdG9wPgogICAgICAgIDxzdG9wIG9mZnNldD0iMSIgc3R5bGU9InN0b3AtY29sb3I6IzAxNDg4MCI+CiAgICAgICAgPC9zdG9wPgogICAgICAgPC9yYWRpYWxHcmFkaWVudD4KICAgICAgIDxwYXRoIGNsYXNzPSJzdDUiIGQ9Ik01MS40LDI1LjhjLTAuMiwwLTIwLDAuNS0yNS40LDAuNVMwLjgsMjUuOCwwLjYsMjUuOGMtMC4yLDAtMC4zLDAuMS0wLjIsMC4yYzAuMSwwLjcsMC4zLDEuNSwwLjYsMi4zCgkJCQkJCQljMCwwLjEsMC4xLDAuMSwwLjIsMC4xQzEuMiwyOC41LDI2LDI3LDI2LDI3czI0LjgsMS41LDI0LjksMS41YzAuMSwwLDAuMiwwLDAuMi0wLjFjMC4yLTAuOCwwLjQtMS41LDAuNi0yLjMKCQkJCQkJCUM1MS43LDI1LjksNTEuNiwyNS44LDUxLjQsMjUuOHoiPgogICAgICAgPC9wYXRoPgogICAgICA8L2c+CiAgICAgPC9nPgogICAgPC9nPgogICA8L2c+CiAgPC9nPgogPC9nPgo8L3N2Zz4=" alt="Konica Minolta" style="width:44px;height:auto;object-fit:contain">
                </div>
                <div class="mega-brand-info">
                  <div class="mega-brand-name">Konica Minolta</div>
                  <div class="mega-brand-desc">A3 MFP · Production · Industrial</div>
                </div>
                <span class="mega-arrow">→</span>
              </a>
              <a href="canon.html" class="mega-brand">
                <div class="mega-brand-logo canon-logo-wrap" style="background:#fff5f5;padding:6px">
                  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATAAAADICAYAAABvTb0zAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA4ZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTMyIDc5LjE1OTI4NCwgMjAxNi8wNC8xOS0xMzoxMzo0MCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpmOWI4OWVmOC0yZDIyLWY3NGEtOGQzYS01ZjlhMGExZGU4YWEiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6QUY4MjkyODQ1NENBMTFFNjk5M0RCQjIzQjk4MkMyRDUiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6QUY4MjkyODM1NENBMTFFNjk5M0RCQjIzQjk4MkMyRDUiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUuNSAoV2luZG93cykiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDoxOTZiOThkYi05ZDczLWU5NDctYmJmOC00Zjk0MGEzZGIyZmMiIHN0UmVmOmRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDpkYjIzOTA2MS01NGM5LTExZTYtOTc2My1mMzM2MjI3ODA0NzUiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz48sP++AAASgUlEQVR42uydCbRd0xnHdxIaYog5opEGEURDM5gSmpjaUkNiSilShMRYpSlaC63W1FKlKmZFDTUPNdQUGkNLghhSFKESU2KmhOR1/9f93nLXW/fde87Z+9x73n2/31rfSt579+yz7zn7/Pe3v/3tfbq0tLQ4AICOSFcuAQAgYAAACBgAAAIGAAgYAAACBgCAgAEAIGAAgIABACBgAAAIGAAgYAAACBgAAAIGAICAAQACBgCAgAEAIGAAgIABACBgAAAIGAAAAgYACBgAAAIGAICAAQACBgCAgAEAIGAAAAgYACBgAAAIGAAAAgYACBgAAAIGAICAAQAgYACAgAEAIGAAAAgYACBgAAAIGAAAAgYAgIABAAIGAICAAQAgYACAgAEAIGAAAAgYAAACBgAIGAAAAgYAgIABACBgAICAAQAgYAAACBgAIGAAAAgYAAACBgCAgAEAAgYAgIABACBgAICAAQAgYAAACBgAAAIGAAgYAAACBgCAgAEAAgYAUHgWyfsE07p0yfsU/b2t7W01b6ubreytu7fFvC3pbaGJ9Yfe5nv71Nsb3v7j7RWzmd5eo0kAxGFoS0vHF7Ac6OtthLfvelvL23reeiQ89utV/va+t2e8Pe3tLm8PeZtLMwQoLl1aclbJSB7YKt628Tba22beetbh2shDm+rtem93mPcGAAXywIouYOt4O9Tbrt5WaOC9mOXtKm+TGWYCIGC16OXtOG8TXbEmGuSFnevtt97m0UQBELC2HGLitWJOVVKc6ylVzTyr/5kwKdC/lHl6iq0NNQ9wjQplzPF2vLcLaaYAjROwIgXxNXN4mbetcyj7BRsCKpb1zxTHaSZzlLc9vH3f2/L2e8XkLrC/TfD2Cc0VoP4UxQPb1NvVrvosYVZv63RvV3j7MrCs3uYdTigTMvGit128zaA5AdTXAytCfGkvb/dHFi+J1S+8DfZ2aQTxEm9Ymd/y9kHZ79d0pdnKrQpwLRf31q0g9fhajqOGxYvkBLhSvmG3AmpIj5zLXrTRX7DRQ0h5M5Mjlznd297ens2pzso/W7LN7xQ7U+7Y97zdXcfGuZG37bwNdKWJD9Xjc2+vm/f5N+sc6sE3ve3ubbi3PtZpzLLzX+LtnYCylzcvV991dRPH2a4Uy7wyZVggBMVD13elVJ6+Zq0J0/PLrv1s69TUFv9dZzHd3q7Vut6Wsc5Wo4QbvF0TWL467x9Yu1vVvvPL3u6ze/xeZxpCyvO6LPLpbrKH6LOcvk4feyjb620XuFJcbGqOl1QCMbbsYa7FE9ZJnJ9TfRSzPNjbjlU+o4Tgo71dlLJsCYRmovc1gW6PC60zXJjD9+tpD+1O3rbM4Gk96O1Wb5d7eyune7CEt3F2rQZV+dzj3vaxzi3tPVb4ZIcaI5RjvV1czyFkowRsE28PRz6VeuIf5ny97k4wVPzYer+Y+WIDykRrw4xl3GeNN1a9drZGPSrFMZpdPjHB59a3h3FciuHiI942Ny8o1jD4SKtHjPDG+9aJKCb7dqQ6asZ8vIl3v4THfGTXaVqCz0q0D015jxVmOamZBWxZc2mXj3iav9vQLk/kll+b8LMz7CEMoZd5NWNsaBqDN11pRcOTGY9f1DznA70Ny1iGzn9nO38baaK4S8aydX92i3Cd9B1PqODh3mae1Mvm9cgzOdz+nxQNpX/p7ZyA+vUz0RrvsiV4qx0oVejDdsJKe3o7yNsGIfe4WQXsVvMkYqEF2eu4OIH6ar3xbBPfNMPZsRYnSDMU2NqGLNtaTCs2H1m8Ko0n1tOGcROs4YfwX1dagF9+XXYw4YqRQiPvYkpADOki81STeo997V4PTnmu210pVpsmIXqYeYQS2NBJEnmCPy37eSkTxANcaXOEECTwQ7yAfdBsAqa1jDdGPoUCi0/lfJ3OsxubhqvtQUgSj1Maya52ffq6/Jlh163WzdfQaX/77r0jnl9JwtPLvLlNIpZ9fUYPTh7vHe0IUa3whK7TzAwdzqvWmdeKSW3h7TBXPc6YxQvTPV3a24+tc4qZCbC/F7DcE73rKWBdTZm/EbH4tr1IHmjG5dEUn7/XlbL0H6ryGc0gjjDRUqNcydWfSd5+144XsrUJy+iczv2gnWezHMp+3YZYC1Ico07jH1U6j4EmUNW4wDyYtMhL0eRA25jUCjYcPjSCR1SJBeY5qh2unEP5V3oByzsmXVcBG283ORbz7MJ/mfM1mpmwAb1qw4xaM6saBuxujVYZ/VrK9J4NqVpSNkAJ3xoZv9cn1uOWu/nLmNc4zv72jn2ufHZPdexmw9DFIlxfBbTn2APbJ9IQub9LHijXd37CtR8En2Xl1RLEHU0QsqBY1BBvL9nPurZHuFJMsId5S/Mr3H/FkQdEaufPu9IEiEIE3SOUd58XsC2bScCSCkFSjvJ2Ws7XR+c4pcZnFlo9TrKHpxaKoy3q4sxE9bGYUlYUqD237GfVazmrW0uCBj8gwvU9x0RSMR3F2f5k3lmIgA00TywJU80LaY9X7KH+okY5K9lnsyaPlp9nabsXteJjEoh7Au+BYsgTbeTgTMiVDrFfYLn3ewHbIm8Bq1cm/ojI4vVJmwcvD1Y1UaqG4lxKmTgmoXg587ZiTaPrIX0y4Pjt2/ysh+etlJ5gViaa8LeuI5WHoXy1MYHltrjk+WAn1xAvZyGP/gk9yccC6q0dha8o88jm1eH5nWff/942Huf4srpkZWE9hKVeAjY2cnk3pRCMrFxa5fpMtd5PQ8F6ZlpX7OkCjlXwPMvmkN0DvSStkjivnb/d7ErxqLzRTr5HJ3xGRiUs84HAOinmtW2Kz4cu5TmrSmd6jEsXR2wI9RAwpSDEdiWvz7nOu7ZTZ2Uba7ZGwef7CnIPpwQcq/jPRg2ocy2v8bE61OHiFJ/dPOHnYrQJzdzVa4nfUzW8+9kIWKmnGxixvM8CH9paKIZRabLhTFcKrp5fsHuoaxGSfd6IRei1hhd5D2Hl5QxN8XmluSTJu9JSnTcD69bbhteNfv67udpxv04hYIMChxtt0Us38lw0enabYZWGq8qZ+om3dwt4DxUveSjg+M0K2O7y3tnh2AyikkTwFM97NEL9JhXgPnR1HeC1i/WoYP/I5b2UY103dqWZsNbeVJsYjnH5J8o2chipB7OP6zxo0iVL4mzSVQL3Rqhj3xTD1k5NPQQs9iaFr+Y4dNSCYM2GKetZ68Bub8A96W4eYD9XmgntmcAjCYm9KBD87U7U5rOulUx6jWKFN/ZAnmpTj2Bh7PV8ebxMQ6JxogmBkjhfr+M9UP6Q0hkUKxxsHqtES0miigUpvqXUhta9/LVwve0snYYt2rIm65ubNGFxZSdp8yMDvPPlEoQRnnOlLcxDc+S2dFAID6x75PLyyLxXgPZqazT1Ei/tMHGdeZQXmteneFRv8wa7muel/69mIqfYzYP2kBzpvorVLbDfZ2XTjhDviICuV9ZZVy20H57gcwtdnDQQ3fN1kKjGC9j8yOXlsU2ucsoeq9M1H2nDDC0c3tllW46jhq11jFrdcKD97tKAOikDfGAnaO9ru7DlT0lnbGOl2AxBohovYLETTpfuwNf7VBOvkZHKk7empTc32NBmbkBZnSFoHDqhlHTG9oFIHfdqSFTjBSz2kKwjzpgp1niLt5/lVP4YKz8kXWWLTtDeQ981un5CUVEC6LQI9V3JQcMFLHbaw5od8Drr5RrbRypLgf1KCYYKMIfscruJy/ctNkVgycDju6Xwnh+MUN/FHTRcwJR4GnNh5yAXdzvqvFGs6juBZWjiQoH+ncwDUGqK8pmUsX1XpHpqQ78Nmry9x0ioTjo7eK+DphGwFyKWpyDsiA5yfVXPIwPLUNqEljBpZ1TtZqtZS+3TpZlILYjWbKb2ooqRXtLsw8iPI93TJOlHetVb6IqRzxw0XMC0vCL2a8Z26iDX98zA4/WSCr2s5Pkan7vFhoChD8zIJm/vcyOUIQ94vQSf0xKv0GVF7zhouICJ2EmSSj9YouDXVjlDwwKO10ZzabLGX3The6ZrCLlyE7f3WPHYpDO2UwLPMwuJKoaA3W8PWCwUjD2g4Nc29PVeWfb6VwJlyFZDCuJv3MTtXXu3xdhhIamAhcbBnkCiiiFg4ozI5f3cFTt7fHjAsdpe+OaMx54VWO+tmri9K1cuRsKyRD7JRpBa+pV1y28d94yDwgiY3rc3J2J5Wvf364JeV3ky/QKOD9keR68rCwlWN/vC7gcilKFZ8CRvSNfscdZ0Co1aWhwURsDkuh8RuUxte7tuAa+ncrJClqyEJP9KvN4KOF5LitZu4jZ/XaRyks7YZt3y+2rkqVgCJq5x4W9RacuNBRlK6kUIrS/y1KvSQnLfQhfAh4inkjU3beI2P90slKQztlk8KW1dfifyVDwBE3u6OPk4razp4r/tOy1ak6htqFtf5KmcrJDXqod4ldoMr1fg92n2rVxOiVCGtj5KstedXuY8I2XZf2D4WFwB0/Bmh8hlqryLG3QNlXbQGlf5Wpn4hLytSMmSWff2Ut5Y6D5vw138bZCKhPLrZgaWkSahOk0cTBMNZyNNxRWwVrd6/8hl7mND1EXq+D20Dc1U99X6zIfdV6+pujugXOW4ZV34HSPO2Nc8jGZmfIQy8the5xBvnyJNxRYwcaGLH9TfzXq7AXWo/y6uNE2+Rlkvq/yg1uxpJe+GvFdvkkufiqHtemIF4Jt9NlKdzXmBZShWmGR9pTq5JGETrWu9ClnqGAImfu/t4MhlbmLCckROdVa8a7INQ1qHWTeYeJXvAaWUkXMCz3WbS55YOqmN16ZA8MsB5+4M2+toMfzTAcdrY8kkG0HOTXAedXxjHXQoARPakG+0Cwt6V4pPnO5Ka9FirZvU3kx6k7OSCyeU/f40V1raVGnW8TjX/puPk7CseQonuPYD80Ns6HxaheHN5IBza+vl5TrBM7CdC1sjmXTGttoGh0ox2ibyM4CA1ZGb7YF5JHK5KlNLazQLdJQrvd8xDd1MCM6wHvTksof6besxj6py/AcufEmRhijH2/lvsv9rmZG26ZniShvntT2HZkO1W0XI2r9GvbW73rxm9zjrQvhtEnaog9r525cmotMcpGaRAtVFOy4Mt6HfseZ9xEKN5xQzrS+bbv++Zg13oZmWh/SwYYEWNiuetFaF8v5i9UziXWmG8kcubM96od1Ed3TVF2zrO+zu7a/2szL6P3fZZxRHudLe/c2OQg6aUdTGk2m3cd7WhpLVZjUPacebVdsb4+KsDkDACsIZ9gD+xtveOZQ/2GWfYXvSlZYvpV0w/WcbJlzikr2iPgtaO6ccu/Ipe6WsPO6y7582qhM9CxKgYdbRpNk9d1EbwmvTyjcr/F3hhVMr/F77he3l4m5ywBCyIGgpzTjzgpTf9VGD66MFwPua8GXd7eFKE5JHc6ifZtPWd5XzjUJ2RFCZ/TrR86AcrB1siP5uiuMG2RD/GAtTrO5Ks7hKSL2uzXMmj/hXNtpAvJpUwFqR97CfK20gd7iL8769pGh4eJUNETY07ynG99Es6UEuzk4Dt5qXNNG1H8MJ2ZtdQ89KkyCKy4W8cb1Wkm7I5IHeWtUt8LqebuL9R1fakDPpdzrJQhNP2rDwsDbD+0utEzzexdlmPXTP/GrvQAi9x73q8ZAWcQhZiVnWm8m0vfJG5rKv6eIlXCqYOsPiIYqFTHVhi6Krca55TWNMIDST1TfFMFYPx+UuWeBXEyO3uOwv7Kj0oCm/7dqABj6lxt/lpa6SsexPXZxEUI0CDnWlVB8NzUenaGtLtRma3mZhhGdzCBvcE/hcVbvvCuVk3eCyLnuZdWlpyXfJ1bQuXfL+DvLOlEyqJTwD7KHqab14N/MitAHi+3ZTPjdvRVv+Kk/qJfOGtAfXcw0S6GVs6LGWfYcVrXdtMQ9gjg1RZuU0BIVkKAQw1DrQvtbWFNPULON8szfsfv3LTB3hF53xYg1tyX85Z+4CBgCQF125BACAgAEAIGAAAAgYACBgAAAIGAAAAgYAgIABAAIGAICAAQAgYACAgAEAIGAAAAgYAAACBgAIGAAAAgYAgIABAAIGAICAAQAgYAAACBgAIGAAAAgYAAACBgAIGAAAAgYAgIABACBgAICAAQAgYAAACBgAIGAAAAgYAAACBgCAgAEAAgYAgIABACBgAICAAQAgYAAACBgAAAIGAAgYAAACBgCAgAEAAgYAgIABACBgAAAIGAAgYAAACBgAAAIGAICAAQACBgCAgAEAIGAAgIABACBgAAAIGAAAAgYACBgAAAIGAICAAQACBgCAgAEAIGAAAAgYACBgAAAIGAAAAgYACBgAAAIGAJAX/xdgAFchVpSS+lA8AAAAAElFTkSuQmCC" alt="Canon" style="width:44px;height:auto;object-fit:contain">
                </div>
                <div class="mega-brand-info">
                  <div class="mega-brand-name">Canon</div>
                  <div class="mega-brand-desc">Office MFP · Production · LFP</div>
                </div>
                <span class="mega-arrow">→</span>
              </a>
              <div class="mega-footer-strip">
              <span>Authorised partner for HP · Konica Minolta · Canon</span>
              <a href="deals.html">View Current Deals →</a>
            </div>
          </div>
        </div>
      </li>

      <li><a href="blog.html" class="nav-link" data-page="blog">Blog</a></li>
      <li><a href="deals.html" class="nav-link nav-deals" data-page="deals">Current Deals</a></li>
      <li><a href="index.html#contact" class="nav-cta">Contact Us</a></li>
    </ul>

    <button class="nav-hamburger" id="nav-hamburger" aria-label="Menu">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>

<!-- Mobile menu -->
<div class="mobile-menu" id="mobile-menu">
  <a href="index.html">Home</a>
  <a href="about.html">About Us</a>
  <div class="mobile-section-label">Partners</div>
  <a href="hp.html" class="mobile-brand-link hp-m">HP</a>
  <a href="konica-minolta.html" class="mobile-brand-link km-m">Konica Minolta</a>
  <a href="canon.html" class="mobile-brand-link canon-m">Canon</a>
  <a href="blog.html">Blog</a>
  <a href="deals.html" style="color:var(--teal)">Current Deals</a>
  <a href="index.html#contact" style="background:var(--teal);color:var(--navy);padding:.75rem 1.25rem;border-radius:0;font-weight:600;text-align:center">Contact Us</a>
</div>
`;

const FOOTER_HTML = `
<footer id="main-footer">
  <div class="footer-inner">
    <div class="footer-col">
      <div class="footer-logo">
        <svg width="26" height="26" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
          <g transform="translate(60,60)">
            <polyline points="-44,-34 -20,0 -44,34" fill="none" stroke="#9FE1CB" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
            <polyline points="-16,-34 8,0 -16,34" fill="none" stroke="#1D9E75" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
            <polyline points="12,-34 36,0 12,34" fill="none" stroke="#0F6E56" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
            <circle cx="50" cy="0" r="9" fill="#185FA5"/>
          </g>
        </svg>
        <span class="footer-logo-text">Synergy<span>ICT</span></span>
      </div>
      <div class="footer-tagline">Imaging · Automation · Digital Transformation</div>
      <div class="footer-reg">Reg: 2026/262162/07 · B-BBEE Level 1 EME</div>
    </div>
    <div class="footer-col">
      <div class="footer-col-title">Company</div>
      <a href="index.html">Home</a>
      <a href="about.html">About Us</a>
      <a href="blog.html">Blog & Insights</a>
      <a href="deals.html">Current Deals</a>
      <a href="index.html#contact">Contact</a>
    </div>
    <div class="footer-col">
      <div class="footer-col-title">Partners</div>
      <a href="hp.html">HP</a>
      <a href="konica-minolta.html">Konica Minolta</a>
      <a href="canon.html">Canon</a>
    </div>
    <div class="footer-col">
      <div class="footer-col-title">Contact</div>
      <a href="mailto:info@synergyict.co.za">info@synergyict.co.za</a>
      <a href="https://www.synergyict.co.za">www.synergyict.co.za</a>
      <a href="mailto:info@synergyict.co.za" style="margin-top:.75rem;display:inline-flex;align-items:center;gap:6px;padding:.45rem 1rem;background:var(--teal);color:var(--navy);border-radius:0;font-size:.75rem;font-weight:600;text-decoration:none">Get in Touch →</a>
    </div>
  </div>
  <div class="footer-bottom">
    <span>© 2026 SynergyICT (Pty) Ltd. All rights reserved.</span>
    <span>Authorised Partner — HP · Konica Minolta · Canon · Westcon Comstor Reseller</span>
  </div>
</footer>
`;

const NAV_CSS = `
<style id="shared-nav-css">
:root{
  --nav-h:70px;
  --navy:#042C53;--navy2:#0a1f3a;--teal:#1D9E75;--teal2:#0F6E56;
  --teal-lt:#9FE1CB;--blue:#185FA5;--white:#fff;--off:#f4f8fc;
  --border:#dde3ed;--body:#3d4d63;--gray:#8a96a8;
  --hp-blue:#0096D6;--hp-dark:#00638A;
  --km-red:#1a6edb;--km-dark:#1050a8;
  --canon-red:#CC0000;--canon-dark:#990000;
  --sharp-red:#E8001A;--sharp-dark:#B00014;
}
#main-nav{position:fixed;top:0;left:0;right:0;z-index:200;height:68px;background:transparent;transition:background .35s,box-shadow .35s}
#main-nav.dark-hero{background:linear-gradient(180deg,rgba(3,18,36,.7) 0%,rgba(3,18,36,0) 100%);}
#main-nav.scrolled{background:rgba(3,18,36,.96);backdrop-filter:blur(20px);box-shadow:0 1px 0 rgba(255,255,255,.06)}
#main-nav.nav-light{background:rgba(255,255,255,.97);backdrop-filter:blur(16px);border-bottom:1px solid var(--border)}
#main-nav.nav-light .nav-logo-text{color:var(--navy)}
#main-nav.nav-light .nav-link{color:var(--body)}
#main-nav.nav-light .nav-link:hover{color:var(--navy)}
#main-nav.nav-light .mega-trigger{color:var(--body)}
#main-nav.nav-light .nav-hamburger span{background:var(--navy)}
.nav-inner{max-width:1280px;margin:0 auto;padding:0 6vw;height:68px;display:flex;align-items:center;justify-content:space-between}
.nav-logo{display:flex;align-items:center;gap:10px;text-decoration:none}
.nav-logo-text{font-family:'Syne',sans-serif;font-weight:800;font-size:1.1rem;letter-spacing:-.02em;color:var(--white);transition:color .3s}
.nav-logo-text span{color:var(--teal)}
.nav-links{display:flex;align-items:center;gap:2rem;list-style:none;margin:0;padding:0}
.nav-link{color:rgba(255,255,255,.55);text-decoration:none;font-size:.8rem;font-weight:500;transition:color .2s;background:none;border:none;cursor:pointer;font-family:inherit;padding:0;display:flex;align-items:center;gap:4px;letter-spacing:.01em}
.nav-link:hover{color:var(--white)}
.nav-link.active{color:var(--white)}
.nav-deals{color:var(--teal-lt)!important;font-weight:600}
.nav-deals:hover{color:var(--teal)!important}
.nav-cta{padding:.45rem 1.1rem;background:var(--teal);color:var(--navy)!important;border-radius:0;font-weight:600;text-decoration:none;font-size:.78rem;letter-spacing:.01em;transition:background .2s}
.nav-cta:hover{background:var(--teal-lt)}
.chevron{font-size:.65rem;transition:transform .2s}
.has-mega{position:relative}
.mega-trigger[aria-expanded="true"] .chevron{transform:rotate(180deg)}

/* MEGA MENU */
.mega-menu{
  position:absolute;top:calc(100% + 12px);left:50%;transform:translateX(-50%);
  background:var(--white);border:1px solid var(--border);border-radius:0;
  box-shadow:0 20px 60px rgba(4,44,83,.15);
  opacity:0;pointer-events:none;transform:translateX(-50%) translateY(-8px);
  transition:opacity .2s,transform .2s;
  min-width:580px;
}
.mega-menu.open{opacity:1;pointer-events:all;transform:translateX(-50%) translateY(0)}
.mega-inner{padding:1.5rem}
.mega-label{font-size:.7rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--gray);margin-bottom:1rem}
.mega-brands{display:grid;grid-template-columns:1fr 1fr;gap:.75rem}
.mega-brand{display:flex;align-items:center;gap:.85rem;padding:.85rem 1rem;border:1px solid var(--border);border-radius:0;text-decoration:none;transition:border-color .2s,box-shadow .2s,background .2s}
.mega-brand:hover{border-color:var(--teal);box-shadow:0 4px 16px rgba(29,158,117,.08);background:rgba(29,158,117,.02)}
.mega-brand-logo{width:52px;height:40px;border-radius:0;display:flex;align-items:center;justify-content:center;flex-shrink:0;border:1px solid var(--border)}
.hp-logo-wrap{background:#f0f8ff}
.hp-mega-img{width:36px;height:36px;object-fit:contain}
.km-logo-wrap{background:#fff5f5}
.km-text{font-family:'Syne',sans-serif;font-size:.6rem;font-weight:800;color:var(--km-red);line-height:1.2;text-align:center}
.canon-logo-wrap{background:#fff5f5}
.canon-text{font-family:'Syne',sans-serif;font-size:.8rem;font-weight:800;color:var(--canon-red)}
.sharp-logo-wrap{background:#fff5f5}
.sharp-text{font-family:'Syne',sans-serif;font-size:.8rem;font-weight:800;color:var(--sharp-red)}
.mega-brand-name{font-family:'Syne',sans-serif;font-size:.9rem;font-weight:700;color:var(--navy)}
.mega-brand-desc{font-size:.75rem;color:var(--gray);margin-top:2px}
.mega-arrow{margin-left:auto;color:var(--gray);font-size:.9rem;transition:transform .2s}
.mega-brand:hover .mega-arrow{transform:translateX(3px);color:var(--teal)}
.mega-footer-strip{display:flex;justify-content:space-between;align-items:center;margin-top:1rem;padding-top:.85rem;border-top:1px solid var(--border)}
.mega-footer-strip span{font-size:.75rem;color:var(--gray)}
.mega-footer-strip a{font-size:.78rem;font-weight:600;color:var(--teal2);text-decoration:none}
.mega-footer-strip a:hover{color:var(--teal)}

/* HAMBURGER */
.nav-hamburger{display:none;flex-direction:column;gap:5px;background:none;border:none;cursor:pointer;padding:4px}
.nav-hamburger span{display:block;width:22px;height:2px;background:var(--white);border-radius:0;transition:all .3s}
.nav-hamburger.open span:nth-child(1){transform:rotate(45deg) translate(5px,5px)}
.nav-hamburger.open span:nth-child(2){opacity:0}
.nav-hamburger.open span:nth-child(3){transform:rotate(-45deg) translate(5px,-5px)}

/* MOBILE MENU */
.mobile-menu{
  position:fixed;top:70px;left:0;right:0;bottom:0;z-index:199;
  background:var(--navy);padding:1.5rem 6vw;
  display:flex;flex-direction:column;gap:.5rem;
  overflow-y:auto;
  transform:translateX(100%);transition:transform .3s ease;
}
.mobile-menu.open{transform:translateX(0)}
.mobile-menu a{color:rgba(255,255,255,.8);text-decoration:none;font-size:1rem;font-weight:500;padding:.6rem 0;border-bottom:1px solid rgba(255,255,255,.06)}
.mobile-menu a:hover{color:var(--teal)}
.mobile-section-label{font-size:.65rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--gray);margin-top:1rem;margin-bottom:.25rem}
.mobile-brand-link{padding-left:1rem!important}
.hp-m{color:rgba(0,150,214,.9)!important}
.km-m{color:rgba(26,110,219,.9)!important}
.canon-m{color:rgba(204,0,0,.9)!important}

/* FOOTER */
#main-footer{
  background:var(--navy);
  border-top:1px solid rgba(255,255,255,.06);
  margin-top:auto;
}
.footer-inner{
  max-width:1280px;margin:0 auto;
  padding:56px 6vw 40px;
  display:grid;grid-template-columns:1.8fr 1fr 1fr 1fr;gap:3rem;
}
.footer-logo{display:flex;align-items:center;gap:10px;margin-bottom:.6rem}
.footer-logo-text{font-family:'Syne',sans-serif;font-size:1rem;font-weight:700;color:#fff;letter-spacing:-.01em}
.footer-logo-text span{color:var(--teal)}
.footer-tagline{font-size:.72rem;color:rgba(255,255,255,.28);letter-spacing:.1em;text-transform:uppercase;margin-bottom:.35rem}
.footer-reg{font-size:.68rem;color:rgba(255,255,255,.18)}
.footer-col-title{
  font-size:.65rem;font-weight:700;letter-spacing:.12em;
  text-transform:uppercase;color:rgba(255,255,255,.35);
  margin-bottom:1rem;
}
.footer-col a{
  display:block;color:rgba(255,255,255,.45);
  text-decoration:none;font-size:.82rem;
  margin-bottom:.5rem;transition:color .2s;
}
.footer-col a:hover{color:var(--teal)}
.footer-bottom{
  max-width:1280px;margin:0 auto;
  padding:.875rem 6vw;
  border-top:1px solid rgba(255,255,255,.05);
  display:flex;justify-content:space-between;align-items:center;
  flex-wrap:wrap;gap:.5rem;
}
.footer-bottom span{font-size:.7rem;color:rgba(255,255,255,.2)}

/* PROGRESS BAR */
#progress{position:fixed;top:0;left:0;height:2px;background:linear-gradient(90deg,var(--teal),var(--blue));z-index:300;width:0%;transition:width .1s linear;pointer-events:none}

/* Body layout — footer always at bottom */
html,body{overflow-x:hidden}
body{display:flex;flex-direction:column;min-height:100vh}
#brand-sections,section,.brand-section{flex-shrink:0}
#main-footer{margin-top:auto}
/* No global body padding-top — each page hero handles nav clearance */

@media(max-width:960px){
  .nav-links{display:none}
  .nav-hamburger{display:flex}
  .footer-inner{grid-template-columns:1fr 1fr}
  .mega-menu{display:none}
}
@media(max-width:600px){
  .footer-inner{grid-template-columns:1fr}
}

/* Footer mobile */
@media(max-width:768px){
  #main-footer{padding:40px 5vw 0}
  .footer-inner{grid-template-columns:1fr 1fr;gap:2rem}
  .footer-bottom{flex-direction:column;text-align:center;gap:.4rem}
  .mega-brands{grid-template-columns:1fr}
  .mega-menu{min-width:calc(100vw - 2rem);left:50%;transform:translateX(-50%)}
}
@media(max-width:480px){
  .footer-inner{grid-template-columns:1fr}
  #main-footer{padding:35px 4vw 0}
}
</style>`;

// ── Inject into page ──
document.head.insertAdjacentHTML('beforeend', NAV_CSS);
document.body.insertAdjacentHTML('afterbegin', '<div id="progress"></div>');
document.body.insertAdjacentHTML('beforeend', FOOTER_HTML);

// Find nav placeholder or prepend
const navPlaceholder = document.getElementById('nav-placeholder');
if (navPlaceholder) {
  navPlaceholder.outerHTML = NAV_HTML;
} else {
  document.body.insertAdjacentHTML('afterbegin', NAV_HTML);
}

// ── Active page highlighting ──
const page = document.body.dataset.page;
document.querySelectorAll('.nav-link[data-page]').forEach(a => {
  if (a.dataset.page === page) a.classList.add('active');
});

// ── Nav scroll behaviour ──
const nav = document.getElementById('main-nav');
const isHeroLight = document.body.dataset.heroLight === 'true';
const isDarkHero  = !isHeroLight; // all pages except explicitly light ones

// Start with gradient overlay on dark hero pages so nav is always legible
if (isDarkHero) nav.classList.add('dark-hero');

function updateNav() {
  if (isHeroLight) {
    // Light hero pages — always show solid light nav
    nav.classList.add('nav-light');
    nav.classList.remove('scrolled','dark-hero');
  } else if (window.scrollY > 60) {
    // Scrolled down — solid dark nav
    nav.classList.add('scrolled');
    nav.classList.remove('dark-hero','nav-light');
  } else {
    // At top on dark hero — gradient overlay
    nav.classList.add('dark-hero');
    nav.classList.remove('scrolled','nav-light');
  }
}
window.addEventListener('scroll', updateNav);
updateNav();

// ── Mega menu ──
const trigger = document.getElementById('partners-trigger');
const megaMenu = document.getElementById('mega-menu');
const megaBtn  = trigger?.querySelector('.mega-trigger');
if (trigger) {
  trigger.addEventListener('mouseenter', () => {
    megaMenu.classList.add('open');
    megaBtn.setAttribute('aria-expanded','true');
  });
  trigger.addEventListener('mouseleave', () => {
    megaMenu.classList.remove('open');
    megaBtn.setAttribute('aria-expanded','false');
  });
  megaBtn.addEventListener('click', () => {
    const open = megaMenu.classList.toggle('open');
    megaBtn.setAttribute('aria-expanded', open);
  });
}

// Touch support for mega menu
if('ontouchstart' in window){
  const mBtn = document.querySelector('.mega-trigger');
  if(mBtn){
    mBtn.addEventListener('touchend', e => {
      e.preventDefault();
      const open = megaMenu.classList.toggle('open');
      megaBtn.setAttribute('aria-expanded', open);
    });
  }
}

document.addEventListener('click', e => {
  if (!trigger?.contains(e.target)) {
    megaMenu?.classList.remove('open');
    megaBtn?.setAttribute('aria-expanded','false');
  }
});

// ── Mobile hamburger ──
const hamburger = document.getElementById('nav-hamburger');
const mobileMenu = document.getElementById('mobile-menu');
hamburger?.addEventListener('click', () => {
  hamburger.classList.toggle('open');
  mobileMenu.classList.toggle('open');
});

// ── Scroll progress ──
const prog = document.getElementById('progress');
window.addEventListener('scroll', () => {
  const s = document.documentElement.scrollTop;
  const h = document.documentElement.scrollHeight - window.innerHeight;
  prog.style.width = (h > 0 ? s/h*100 : 0) + '%';
});

// ── Scroll reveal ──
const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
}, { threshold: .1 });
function initReveal() {
  document.querySelectorAll('.reveal,.reveal-left,.reveal-right,.stagger-children').forEach(el => revealObserver.observe(el));
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initReveal);
} else {
  initReveal();
}
