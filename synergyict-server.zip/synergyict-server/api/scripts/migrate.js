'use strict';
require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const pool = require('../lib/db');
const { logger } = require('../lib/logger');

async function migrate() {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // ── Admin users ──
    await client.query(`
      CREATE TABLE IF NOT EXISTS admin_users (
        id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
        email      TEXT        NOT NULL UNIQUE,
        google_id  TEXT        UNIQUE,
        name       TEXT,
        avatar     TEXT,
        role       TEXT        NOT NULL DEFAULT 'admin',
        active     BOOLEAN     NOT NULL DEFAULT true,
        last_login TIMESTAMPTZ,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);

    // ── Products ──
    await client.query(`
      CREATE TABLE IF NOT EXISTS products (
        id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
        brand             TEXT        NOT NULL,
        category          TEXT        NOT NULL,
        name              TEXT        NOT NULL,
        model             TEXT,
        description       TEXT,
        specs             TEXT[],
        cash_price        NUMERIC(12,2),
        leasing_available BOOLEAN     NOT NULL DEFAULT false,
        lease_12m         NUMERIC(12,2),
        lease_24m         NUMERIC(12,2),
        lease_36m         NUMERIC(12,2),
        is_featured       BOOLEAN     NOT NULL DEFAULT false,
        is_new            BOOLEAN     NOT NULL DEFAULT false,
        sort_order        INTEGER     NOT NULL DEFAULT 0,
        created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);

    // ── Blog posts ──
    await client.query(`
      CREATE TABLE IF NOT EXISTS posts (
        id               UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
        title            TEXT        NOT NULL,
        slug             TEXT        NOT NULL UNIQUE,
        content          TEXT        NOT NULL DEFAULT '',
        excerpt          TEXT,
        cover_image_url  TEXT,
        category         TEXT        NOT NULL,
        tags             TEXT[],
        author_name      TEXT        NOT NULL DEFAULT 'SynergyICT',
        author_avatar    TEXT,
        status           TEXT        NOT NULL DEFAULT 'draft',
        published_at     TIMESTAMPTZ,
        seo_title        TEXT,
        seo_description  TEXT,
        read_time_mins   INTEGER,
        view_count       INTEGER     NOT NULL DEFAULT 0,
        created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);

    // ── Indexes ──
    await client.query(`CREATE INDEX IF NOT EXISTS idx_products_brand     ON products(brand)`);
    await client.query(`CREATE INDEX IF NOT EXISTS idx_products_category  ON products(category)`);
    await client.query(`CREATE INDEX IF NOT EXISTS idx_products_order     ON products(brand, sort_order, name)`);
    await client.query(`CREATE INDEX IF NOT EXISTS idx_posts_slug         ON posts(slug)`);
    await client.query(`CREATE INDEX IF NOT EXISTS idx_posts_status       ON posts(status)`);
    await client.query(`CREATE INDEX IF NOT EXISTS idx_posts_category     ON posts(category)`);
    await client.query(`CREATE INDEX IF NOT EXISTS idx_posts_published    ON posts(published_at DESC)`);

    // ── updated_at trigger ──
    await client.query(`
      CREATE OR REPLACE FUNCTION update_updated_at()
      RETURNS TRIGGER AS $$
      BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
      $$ LANGUAGE plpgsql
    `);
    for (const table of ['admin_users', 'products', 'posts']) {
      await client.query(`
        DROP TRIGGER IF EXISTS trg_updated_at ON ${table};
        CREATE TRIGGER trg_updated_at
        BEFORE UPDATE ON ${table}
        FOR EACH ROW EXECUTE FUNCTION update_updated_at()
      `);
    }

    await client.query('COMMIT');
    logger.info('Migration complete — all tables created');
    process.exit(0);
  } catch (err) {
    await client.query('ROLLBACK');
    logger.error('Migration failed', { message: err.message });
    process.exit(1);
  } finally {
    client.release();
  }
}

migrate();
