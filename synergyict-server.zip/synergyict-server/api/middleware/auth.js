'use strict';
const jwt    = require('jsonwebtoken');
const pool   = require('../lib/db');
const { logger } = require('../lib/logger');

async function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or invalid Authorization header' });
  }

  const token = header.slice(7);
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    // Confirm user still exists and is active
    const { rows } = await pool.query(
      'SELECT id, email, role FROM admin_users WHERE id = $1 AND active = true',
      [payload.sub]
    );
    if (!rows.length) {
      return res.status(401).json({ error: 'User not found or deactivated' });
    }
    req.user = rows[0];
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired — please sign in again' });
    }
    logger.warn(`Invalid JWT attempt: ${err.message}`);
    return res.status(401).json({ error: 'Invalid token' });
  }
}

module.exports = { requireAuth };
