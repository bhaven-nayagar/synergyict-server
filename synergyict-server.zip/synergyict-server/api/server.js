'use strict';
require('dotenv').config();

const express    = require('express');
const helmet     = require('helmet');
const cors       = require('cors');
const compression = require('compression');
const morgan     = require('morgan');
const rateLimit  = require('express-rate-limit');
const { logger } = require('./lib/logger');

const authRoutes    = require('./routes/auth');
const productRoutes = require('./routes/products');
const postRoutes    = require('./routes/posts');
const healthRoutes  = require('./routes/health');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Trust Nginx proxy ──
app.set('trust proxy', 1);

// ── Security headers ──
app.use(helmet({
  contentSecurityPolicy: false, // handled by Nginx
  crossOriginEmbedderPolicy: false,
}));

// ── CORS — only allow your domain ──
app.use(cors({
  origin: process.env.ALLOWED_ORIGIN || 'https://synergyict.co.za',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
}));

// ── Body parsing ──
app.use(express.json({ limit: '50kb' }));
app.use(express.urlencoded({ extended: false, limit: '50kb' }));

// ── Compression ──
app.use(compression());

// ── HTTP request logging ──
app.use(morgan('combined', {
  stream: { write: msg => logger.http(msg.trim()) },
}));

// ── Global rate limiter (backup to Nginx) ──
app.use(rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests, please try again later.' },
}));

// ── Routes ──
app.use('/health',   healthRoutes);
app.use('/auth',     authRoutes);
app.use('/products', productRoutes);
app.use('/posts',    postRoutes);

// ── 404 ──
app.use((req, res) => {
  res.status(404).json({ error: 'Not found' });
});

// ── Global error handler ──
app.use((err, req, res, _next) => {
  logger.error(`Unhandled error: ${err.message}`, { stack: err.stack });
  res.status(500).json({ error: 'Internal server error' });
});

// ── Start ──
app.listen(PORT, '127.0.0.1', () => {
  logger.info(`SynergyICT API running on port ${PORT} (${process.env.NODE_ENV})`);
});

module.exports = app;
