'use strict';
const express = require('express');
const pool    = require('../lib/db');
const router  = express.Router();

router.get('/', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({
      status:    'ok',
      service:   'SynergyICT API',
      database:  'connected',
      timestamp: new Date().toISOString(),
    });
  } catch {
    res.status(503).json({ status: 'error', database: 'disconnected' });
  }
});

module.exports = router;
