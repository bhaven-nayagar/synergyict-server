'use strict';
const express    = require('express');
const { body, param, query, validationResult } = require('express-validator');
const pool       = require('../lib/db');
const { requireAuth } = require('../middleware/auth');
const { logger } = require('../lib/logger');

const router = express.Router();

const VALID_CATEGORIES = [
  'Technology & ICT',
  'Managed Print',
  'IoT & Cloud',
  'Digital Transformation',
  'Company News',
];

const VALID_STATUSES = ['draft', 'published'];

// Auto-calculate reading time (avg 200 words/min)
function calcReadTime(content) {
  if (!content) return 1;
  const words = content.replace(/<[^>]*>/g, '').split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.ceil(words / 200));
}

// Generate slug from title
function slugify(title) {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .slice(0, 100);
}

// Generate excerpt from content (strip HTML, first 160 chars)
function autoExcerpt(content) {
  if (!content) return '';
  const text = content.replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim();
  return text.length > 160 ? text.slice(0, 157) + '…' : text;
}

const postValidation = [
  body('title').trim().isLength({ min: 1, max: 300 }),
  body('content').optional({ nullable: true }).isString(),
  body('category').isIn(VALID_CATEGORIES),
  body('tags').optional({ nullable: true }).isArray({ max: 10 }),
  body('author_name').optional({ nullable: true }).trim().isLength({ max: 100 }),
  body('cover_image_url').optional({ nullable: true }).trim().isURL().isLength({ max: 500 }),
  body('status').optional().isIn(VALID_STATUSES),
  body('seo_title').optional({ nullable: true }).trim().isLength({ max: 70 }),
  body('seo_description').optional({ nullable: true }).trim().isLength({ max: 160 }),
  body('slug').optional({ nullable: true }).trim().isLength({ max: 120 })
    .matches(/^[a-z0-9-]+$/).withMessage('Slug must be lowercase letters, numbers and hyphens only'),
];

// ── GET /posts ── public
router.get('/', async (req, res) => {
  try {
    const { category, status = 'published', limit = 20, offset = 0 } = req.query;

    const params = [];
    let where = 'WHERE 1=1';

    // Public requests can only see published posts
    const requestedStatus = status === 'draft' ? 'published' : status;
    params.push(requestedStatus);
    where += ` AND p.status = $${params.length}`;

    if (category && VALID_CATEGORIES.includes(category)) {
      params.push(category);
      where += ` AND p.category = $${params.length}`;
    }

    const lim = Math.min(parseInt(limit) || 20, 50);
    const off = parseInt(offset) || 0;
    params.push(lim, off);

    const { rows } = await pool.query(`
      SELECT id, title, slug, excerpt, cover_image_url, category, tags,
             author_name, author_avatar, status, published_at,
             seo_title, seo_description, read_time_mins, view_count,
             created_at, updated_at
      FROM posts p
      ${where}
      ORDER BY published_at DESC NULLS LAST
      LIMIT $${params.length - 1} OFFSET $${params.length}
    `, params);

    // Total count for pagination
    const countParams = params.slice(0, -2);
    const { rows: countRows } = await pool.query(
      `SELECT COUNT(*) FROM posts p ${where.replace(`$${params.length - 1}`, `$${countParams.length - 0 + 1}`)}`,
      countParams
    );

    res.json({ posts: rows, total: parseInt(countRows[0]?.count || 0) });
  } catch (err) {
    logger.error('GET /posts error', { message: err.message });
    res.status(500).json({ error: 'Failed to fetch posts' });
  }
});

// ── GET /posts/all ── admin only — returns drafts too
router.get('/all', requireAuth, async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT id, title, slug, excerpt, cover_image_url, category, tags,
             author_name, status, published_at, read_time_mins, view_count,
             seo_title, seo_description, created_at, updated_at
      FROM posts
      ORDER BY updated_at DESC
    `);
    res.json({ posts: rows });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch posts' });
  }
});

// ── GET /posts/:slug ── public — by slug, increments view count
router.get('/:slug', async (req, res) => {
  try {
    const slug = req.params.slug.substring(0, 120);
    const { rows } = await pool.query(
      'SELECT * FROM posts WHERE slug = $1 AND status = $2',
      [slug, 'published']
    );
    if (!rows.length) return res.status(404).json({ error: 'Post not found' });

    // Async view count increment (fire and forget)
    pool.query('UPDATE posts SET view_count = view_count + 1 WHERE slug = $1', [slug]).catch(() => {});

    res.json({ post: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch post' });
  }
});

// ── GET /posts/admin/:id ── admin — fetch draft or published by ID
router.get('/admin/:id', requireAuth, param('id').isUUID(), async (req, res) => {
  if (!validationResult(req).isEmpty()) return res.status(400).json({ error: 'Invalid ID' });
  try {
    const { rows } = await pool.query('SELECT * FROM posts WHERE id = $1', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Post not found' });
    res.json({ post: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch post' });
  }
});

// ── POST /posts ── admin only
router.post('/', requireAuth, postValidation, async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  let {
    title, slug, content, category, tags,
    author_name, cover_image_url, status,
    seo_title, seo_description,
  } = req.body;

  // Auto-generate slug if not provided
  if (!slug) slug = slugify(title);

  // Ensure slug is unique — append timestamp if collision
  const { rows: existing } = await pool.query('SELECT id FROM posts WHERE slug = $1', [slug]);
  if (existing.length) slug = `${slug}-${Date.now()}`;

  const excerpt     = autoExcerpt(content);
  const readTime    = calcReadTime(content);
  const publishedAt = status === 'published' ? new Date() : null;

  try {
    const { rows } = await pool.query(`
      INSERT INTO posts
        (title, slug, content, excerpt, cover_image_url, category, tags,
         author_name, status, published_at, seo_title, seo_description, read_time_mins)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
      RETURNING *
    `, [title, slug, content || '', excerpt, cover_image_url || null,
        category, tags || null, author_name || 'SynergyICT',
        status || 'draft', publishedAt, seo_title || null, seo_description || null, readTime]);

    logger.info(`Post created: "${title}" [${status}] by ${req.user.email}`);
    res.status(201).json({ post: rows[0] });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'Slug already exists — choose a different one' });
    logger.error('POST /posts error', { message: err.message });
    res.status(500).json({ error: 'Failed to create post' });
  }
});

// ── PUT /posts/:id ── admin only
router.put('/:id', requireAuth, param('id').isUUID(), postValidation, async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  let {
    title, slug, content, category, tags,
    author_name, cover_image_url, status,
    seo_title, seo_description,
  } = req.body;

  if (!slug) slug = slugify(title);

  const excerpt     = autoExcerpt(content);
  const readTime    = calcReadTime(content);

  // Only set published_at on first publish
  const { rows: existing } = await pool.query(
    'SELECT published_at FROM posts WHERE id = $1', [req.params.id]
  );
  if (!existing.length) return res.status(404).json({ error: 'Post not found' });

  const publishedAt = status === 'published'
    ? (existing[0].published_at || new Date())
    : null;

  try {
    const { rows } = await pool.query(`
      UPDATE posts SET
        title=$1, slug=$2, content=$3, excerpt=$4, cover_image_url=$5,
        category=$6, tags=$7, author_name=$8, status=$9, published_at=$10,
        seo_title=$11, seo_description=$12, read_time_mins=$13, updated_at=NOW()
      WHERE id=$14
      RETURNING *
    `, [title, slug, content || '', excerpt, cover_image_url || null,
        category, tags || null, author_name || 'SynergyICT',
        status || 'draft', publishedAt,
        seo_title || null, seo_description || null, readTime, req.params.id]);

    logger.info(`Post updated: ${req.params.id} by ${req.user.email}`);
    res.json({ post: rows[0] });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'Slug already in use' });
    res.status(500).json({ error: 'Failed to update post' });
  }
});

// ── DELETE /posts/:id ── admin only
router.delete('/:id', requireAuth, param('id').isUUID(), async (req, res) => {
  if (!validationResult(req).isEmpty()) return res.status(400).json({ error: 'Invalid ID' });
  try {
    const { rowCount } = await pool.query('DELETE FROM posts WHERE id = $1', [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: 'Post not found' });
    logger.info(`Post deleted: ${req.params.id} by ${req.user.email}`);
    res.json({ message: 'Post deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete post' });
  }
});

module.exports = router;
