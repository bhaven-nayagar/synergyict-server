'use strict';
const express    = require('express');
const { body, param, validationResult } = require('express-validator');
const pool       = require('../lib/db');
const { requireAuth } = require('../middleware/auth');
const { logger } = require('../lib/logger');

const router = express.Router();

const VALID_BRANDS = ['HP', 'Konica Minolta', 'Canon', 'Sharp'];

const productValidation = [
  body('brand').isIn(VALID_BRANDS).withMessage('Invalid brand'),
  body('category').trim().isLength({ min: 1, max: 100 }),
  body('name').trim().isLength({ min: 1, max: 200 }),
  body('model').optional({ nullable: true }).trim().isLength({ max: 200 }),
  body('description').optional({ nullable: true }).trim().isLength({ max: 2000 }),
  body('specs').optional({ nullable: true }).isArray({ max: 20 }),
  body('cash_price').optional({ nullable: true }).isFloat({ min: 0 }),
  body('leasing_available').optional().isBoolean(),
  body('lease_12m').optional({ nullable: true }).isFloat({ min: 0 }),
  body('lease_24m').optional({ nullable: true }).isFloat({ min: 0 }),
  body('lease_36m').optional({ nullable: true }).isFloat({ min: 0 }),
  body('is_featured').optional().isBoolean(),
  body('is_new').optional().isBoolean(),
  body('sort_order').optional().isInt({ min: 0 }),
];

// ── GET /products ── (public — no auth required)
router.get('/', async (req, res) => {
  try {
    const { brand, category } = req.query;
    let query = 'SELECT * FROM products WHERE 1=1';
    const params = [];

    if (brand) {
      if (!VALID_BRANDS.includes(brand)) return res.status(400).json({ error: 'Invalid brand' });
      params.push(brand);
      query += ` AND brand = $${params.length}`;
    }
    if (category) {
      params.push(category.substring(0, 100));
      query += ` AND category = $${params.length}`;
    }

    query += ' ORDER BY brand, sort_order, name';
    const { rows } = await pool.query(query, params);
    res.json({ products: rows });
  } catch (err) {
    logger.error('GET /products error', { message: err.message });
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

// ── GET /products/:id ── (public)
router.get('/:id',
  param('id').isUUID(),
  async (req, res) => {
    if (!validationResult(req).isEmpty()) return res.status(400).json({ error: 'Invalid ID' });
    try {
      const { rows } = await pool.query('SELECT * FROM products WHERE id = $1', [req.params.id]);
      if (!rows.length) return res.status(404).json({ error: 'Product not found' });
      res.json({ product: rows[0] });
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch product' });
    }
  }
);

// ── POST /products ── (admin only)
router.post('/',
  requireAuth,
  productValidation,
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const {
      brand, category, name, model, description, specs,
      cash_price, leasing_available, lease_12m, lease_24m, lease_36m,
      is_featured, is_new, sort_order,
    } = req.body;

    try {
      const { rows } = await pool.query(`
        INSERT INTO products
          (brand, category, name, model, description, specs,
           cash_price, leasing_available, lease_12m, lease_24m, lease_36m,
           is_featured, is_new, sort_order)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
        RETURNING *`,
        [brand, category, name, model||null, description||null, specs||null,
         cash_price||null, leasing_available||false,
         lease_12m||null, lease_24m||null, lease_36m||null,
         is_featured||false, is_new||false, sort_order||0]
      );
      logger.info(`Product created: ${rows[0].id} "${name}" by ${req.user.email}`);
      res.status(201).json({ product: rows[0] });
    } catch (err) {
      logger.error('POST /products error', { message: err.message });
      res.status(500).json({ error: 'Failed to create product' });
    }
  }
);

// ── PUT /products/:id ── (admin only)
router.put('/:id',
  requireAuth,
  param('id').isUUID(),
  productValidation,
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const {
      brand, category, name, model, description, specs,
      cash_price, leasing_available, lease_12m, lease_24m, lease_36m,
      is_featured, is_new, sort_order,
    } = req.body;

    try {
      const { rows } = await pool.query(`
        UPDATE products SET
          brand=$1, category=$2, name=$3, model=$4, description=$5, specs=$6,
          cash_price=$7, leasing_available=$8, lease_12m=$9, lease_24m=$10,
          lease_36m=$11, is_featured=$12, is_new=$13, sort_order=$14,
          updated_at=NOW()
        WHERE id=$15
        RETURNING *`,
        [brand, category, name, model||null, description||null, specs||null,
         cash_price||null, leasing_available||false,
         lease_12m||null, lease_24m||null, lease_36m||null,
         is_featured||false, is_new||false, sort_order||0,
         req.params.id]
      );
      if (!rows.length) return res.status(404).json({ error: 'Product not found' });
      logger.info(`Product updated: ${req.params.id} by ${req.user.email}`);
      res.json({ product: rows[0] });
    } catch (err) {
      logger.error('PUT /products error', { message: err.message });
      res.status(500).json({ error: 'Failed to update product' });
    }
  }
);

// ── DELETE /products/:id ── (admin only)
router.delete('/:id',
  requireAuth,
  param('id').isUUID(),
  async (req, res) => {
    if (!validationResult(req).isEmpty()) return res.status(400).json({ error: 'Invalid ID' });
    try {
      const { rowCount } = await pool.query('DELETE FROM products WHERE id = $1', [req.params.id]);
      if (!rowCount) return res.status(404).json({ error: 'Product not found' });
      logger.info(`Product deleted: ${req.params.id} by ${req.user.email}`);
      res.json({ message: 'Product deleted' });
    } catch (err) {
      res.status(500).json({ error: 'Failed to delete product' });
    }
  }
);

module.exports = router;
