'use strict';
const express    = require('express');
const { OAuth2Client } = require('google-auth-library');
const jwt        = require('jsonwebtoken');
const rateLimit  = require('express-rate-limit');
const { body, validationResult } = require('express-validator');
const pool       = require('../lib/db');
const { requireAuth } = require('../middleware/auth');
const { logger } = require('../lib/logger');

const router = express.Router();

// One Google OAuth2 client — verifies ID tokens from the frontend
const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

// Rate limiter on all auth endpoints
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { error: 'Too many requests, please try again in 15 minutes.' },
  skipSuccessfulRequests: true,
});

// ─────────────────────────────────────────────
// POST /auth/google
//
// Flow:
//   1. Frontend signs in with Google (using GSI JS library)
//      and receives a credential (ID token)
//   2. Frontend posts that ID token here
//   3. We verify it with Google's public keys
//   4. We check the email domain is @synergyict.co.za
//   5. We upsert the user into admin_users
//   6. We return our own JWT — same as before for all
//      subsequent API calls
// ─────────────────────────────────────────────
router.post('/google',
  authLimiter,
  body('credential').isString().isLength({ min: 10 }),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: 'Missing or invalid Google credential' });
    }

    const { credential } = req.body;

    try {
      // ── 1. Verify the Google ID token ──
      const ticket = await googleClient.verifyIdToken({
        idToken:  credential,
        audience: process.env.GOOGLE_CLIENT_ID,
      });
      const payload = ticket.getPayload();

      // ── 2. Domain restriction ──
      const allowedDomain = process.env.ALLOWED_GOOGLE_DOMAIN || 'synergyict.co.za';
      if (payload.hd !== allowedDomain) {
        logger.warn(`SSO rejected — wrong domain: ${payload.email}`);
        return res.status(403).json({
          error: `Access restricted to @${allowedDomain} accounts only.`
        });
      }

      // ── 3. Email must be verified by Google ──
      if (!payload.email_verified) {
        return res.status(403).json({ error: 'Google account email is not verified.' });
      }

      const googleId = payload.sub;
      const email    = payload.email;
      const name     = payload.name || email;
      const avatar   = payload.picture || null;

      // ── 4. Upsert user ──
      // First time: creates the row. Subsequent logins: updates last_login + name/avatar.
      const { rows } = await pool.query(`
        INSERT INTO admin_users (email, google_id, name, avatar, role, active)
        VALUES ($1, $2, $3, $4, 'admin', true)
        ON CONFLICT (email) DO UPDATE SET
          google_id  = EXCLUDED.google_id,
          name       = EXCLUDED.name,
          avatar     = EXCLUDED.avatar,
          last_login = NOW(),
          updated_at = NOW()
        WHERE admin_users.active = true
        RETURNING id, email, name, avatar, role, active
      `, [email, googleId, name, avatar]);

      if (!rows.length) {
        // ON CONFLICT … WHERE active=true means inactive accounts don't update
        logger.warn(`SSO blocked — inactive account: ${email}`);
        return res.status(403).json({ error: 'Your account has been deactivated. Contact your administrator.' });
      }

      const user = rows[0];

      // ── 5. Issue our JWT ──
      const token = jwt.sign(
        { sub: user.id, email: user.email, role: user.role, name: user.name },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
      );

      logger.info(`SSO login: ${email}`);
      res.json({
        token,
        user: { id: user.id, email: user.email, name: user.name, avatar: user.avatar, role: user.role },
        expires_in: process.env.JWT_EXPIRES_IN || '8h',
      });

    } catch (err) {
      if (err.message?.includes('Token used too late') || err.message?.includes('Invalid token')) {
        return res.status(401).json({ error: 'Google sign-in expired — please try again.' });
      }
      logger.error('Google SSO error', { message: err.message });
      res.status(500).json({ error: 'Authentication failed. Please try again.' });
    }
  }
);

// ── GET /auth/me ──
router.get('/me', requireAuth, (req, res) => {
  res.json({ user: req.user });
});

// ── POST /auth/change-password ── (not applicable for SSO users, kept for future)
router.post('/change-password', requireAuth, (req, res) => {
  res.status(400).json({ error: 'Password management is handled by Google for SSO accounts.' });
});

module.exports = router;
