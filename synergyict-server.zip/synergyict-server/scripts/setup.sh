#!/bin/bash
# ============================================================
# SynergyICT Server Setup Script
# Ubuntu 24.04 LTS — Google SSO edition
# Run as root: bash setup.sh
# ============================================================

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info()    { echo -e "${CYAN}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[OK]${NC} $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }
die()     { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

[[ $EUID -ne 0 ]] && die "Run as root: sudo bash setup.sh"

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║   SynergyICT Server Setup                ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════╝${NC}"
echo ""
warn "Before running this script:"
warn "  1. Your VPS is running Ubuntu 24.04 LTS"
warn "  2. DNS A record for your domain points to this server's IP"
warn "  3. You have your Google OAuth Client ID ready (see SETUP.md)"
echo ""

read -rp  "Domain (e.g. synergyict.co.za):              " DOMAIN
read -rp  "SSL cert email:                               " ADMIN_EMAIL
read -rp  "Google OAuth Client ID:                       " GOOGLE_CLIENT_ID
read -rsp "PostgreSQL password (strong, keep it safe):   " DB_PASSWORD; echo ""
read -rsp "JWT secret (40+ random chars):                " JWT_SECRET; echo ""

[[ ${#DB_PASSWORD} -lt 12 ]] && die "DB password must be at least 12 characters"
[[ ${#JWT_SECRET}  -lt 32 ]] && die "JWT secret must be at least 32 characters"
[[ -z "$GOOGLE_CLIENT_ID" ]] && die "Google Client ID is required"

APP_DIR="/var/www/synergyict"
API_DIR="$APP_DIR/api"
FRONT_DIR="$APP_DIR/frontend"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(dirname "$SCRIPT_DIR")"

echo ""
info "Starting setup for: $DOMAIN"
echo ""

# ── 1. System ──
info "Updating system…"
apt-get update -qq && apt-get upgrade -y -qq
apt-get install -y -qq curl wget git ufw fail2ban unzip
success "System updated"

# ── 2. Firewall ──
info "Configuring UFW firewall…"
ufw --force reset
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable
success "Firewall: SSH + HTTP + HTTPS only"

# ── 3. fail2ban ──
info "Configuring fail2ban…"
cat > /etc/fail2ban/jail.local << 'EOF'
[DEFAULT]
bantime  = 3600
findtime = 600
maxretry = 5
[sshd]
enabled = true
port    = ssh
[nginx-http-auth]
enabled = true
[nginx-limit-req]
enabled  = true
filter   = nginx-limit-req
logpath  = /var/log/nginx/error.log
maxretry = 10
EOF
systemctl enable fail2ban --quiet && systemctl restart fail2ban
success "fail2ban configured"

# ── 4. Node.js 20 ──
info "Installing Node.js 20 LTS…"
curl -fsSL https://deb.nodesource.com/setup_20.x | bash - > /dev/null 2>&1
apt-get install -y -qq nodejs
success "Node.js $(node -v)"

# ── 5. PostgreSQL ──
info "Installing PostgreSQL…"
apt-get install -y -qq postgresql postgresql-contrib
systemctl enable postgresql --quiet && systemctl start postgresql
sudo -u postgres psql -c "CREATE USER synergyict WITH PASSWORD '$DB_PASSWORD';" 2>/dev/null || \
  sudo -u postgres psql -c "ALTER USER synergyict WITH PASSWORD '$DB_PASSWORD';"
sudo -u postgres psql -c "CREATE DATABASE synergyict OWNER synergyict;" 2>/dev/null || true
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE synergyict TO synergyict;"
PG_CONF=$(find /etc/postgresql -name "postgresql.conf" | head -1)
sed -i "s/#listen_addresses = 'localhost'/listen_addresses = 'localhost'/" "$PG_CONF"
systemctl restart postgresql
success "PostgreSQL: localhost only"

# ── 6. Nginx ──
info "Installing Nginx…"
apt-get install -y -qq nginx
systemctl enable nginx --quiet
success "Nginx installed"

# ── 7. Certbot ──
info "Installing Certbot…"
apt-get install -y -qq certbot python3-certbot-nginx
success "Certbot installed"

# ── 8. App dirs + files ──
info "Creating app directories…"
mkdir -p "$API_DIR" "$FRONT_DIR"
cp -r "$REPO_ROOT/api/"* "$API_DIR/"
cp -r "$REPO_ROOT/frontend/"* "$FRONT_DIR/"

# ── 9. .env ──
info "Writing .env…"
cat > "$API_DIR/.env" << EOF
NODE_ENV=production
PORT=3000
DOMAIN=$DOMAIN

DB_HOST=localhost
DB_PORT=5432
DB_NAME=synergyict
DB_USER=synergyict
DB_PASSWORD=$DB_PASSWORD

JWT_SECRET=$JWT_SECRET
JWT_EXPIRES_IN=8h

GOOGLE_CLIENT_ID=$GOOGLE_CLIENT_ID
ALLOWED_GOOGLE_DOMAIN=synergyict.co.za

ALLOWED_ORIGIN=https://$DOMAIN
EOF
chmod 600 "$API_DIR/.env"
chown root:root "$API_DIR/.env"
success ".env written (root-only)"

# ── 10. npm install ──
info "Installing Node dependencies…"
cd "$API_DIR" && npm install --production --silent
success "Dependencies installed"

# ── 11. Database migration ──
info "Running database migration…"
cd "$API_DIR" && node scripts/migrate.js
success "Database schema created"

# ── 12. Nginx config ──
info "Writing Nginx config…"
cp "$REPO_ROOT/nginx/synergyict.conf" /etc/nginx/sites-available/synergyict
sed -i "s/YOUR_DOMAIN/$DOMAIN/g" /etc/nginx/sites-available/synergyict
ln -sf /etc/nginx/sites-available/synergyict /etc/nginx/sites-enabled/synergyict
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
success "Nginx configured"

# ── 13. SSL ──
info "Obtaining SSL certificate…"
warn "Make sure DNS is propagated before continuing."
read -rp "Press Enter when ready (Ctrl+C to abort and run certbot manually later)…"
certbot --nginx --non-interactive --agree-tos \
  --email "$ADMIN_EMAIL" \
  --domains "$DOMAIN,www.$DOMAIN" \
  --redirect
success "SSL certificate obtained + auto-renewal active"

# ── 14. Inject API URL into frontend ──
sed -i "s|YOUR_API_URL|https://$DOMAIN/api|g" "$FRONT_DIR/deals.html"
sed -i "s|YOUR_API_URL|https://$DOMAIN/api|g" "$FRONT_DIR/admin.html"
sed -i "s|YOUR_GOOGLE_CLIENT_ID|$GOOGLE_CLIENT_ID|g" "$FRONT_DIR/admin.html"
success "Frontend configured"

# ── 15. systemd service ──
info "Creating systemd service…"
cat > /etc/systemd/system/synergyict-api.service << EOF
[Unit]
Description=SynergyICT API Server
After=network.target postgresql.service

[Service]
Type=simple
User=www-data
WorkingDirectory=$API_DIR
EnvironmentFile=$API_DIR/.env
ExecStart=/usr/bin/node server.js
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=synergyict-api
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=$API_DIR/logs

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable synergyict-api --quiet
systemctl start synergyict-api
sleep 3
systemctl is-active --quiet synergyict-api \
  && success "API service running" \
  || die "API failed to start — check: journalctl -u synergyict-api -n 50"

# ── Done ──
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   Setup complete!                        ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
echo ""
echo -e "  Deals page:  ${CYAN}https://$DOMAIN/deals.html${NC}"
echo -e "  Admin panel: ${CYAN}https://$DOMAIN/admin.html${NC}"
echo -e "  API health:  ${CYAN}https://$DOMAIN/api/health${NC}"
echo ""
echo -e "  ${YELLOW}First login:${NC} any @synergyict.co.za Google account"
echo -e "  ${YELLOW}To deactivate a user:${NC}"
echo -e "    sudo -u postgres psql synergyict"
echo -e "    UPDATE admin_users SET active=false WHERE email='user@synergyict.co.za';"
echo ""
echo -e "  Useful commands:"
echo -e "    systemctl status synergyict-api"
echo -e "    journalctl -u synergyict-api -f"
echo -e "    nginx -t && systemctl reload nginx"
echo ""
